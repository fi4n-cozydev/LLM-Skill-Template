#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_dashboard.py — สร้าง Dashboard ผลการดำเนินโครงการ เป็นไฟล์ HTML ไฟล์เดียว (เปิดได้ทุกเครื่อง ไม่ต้องต่ออินเทอร์เน็ต)
วิธีใช้:  python build_dashboard.py dashboard.json output/dashboard.html

โครงสร้าง dashboard.json
{ "title": "...", "subtitle": "...", "badge": "ปีงบประมาณ 2569", "updated": "ข้อมูล ณ 30 กันยายน 2569",
  "kpis": [{"value": "120", "label": "ผู้เข้าอบรม (คน)", "note": "เป้าหมาย 100 คน", "status": "good|warn|"}],      # 4–6 ค่า
  "charts": [{"kind": "column|hbar|line|donut", "title": "...", "unit": "คน",
              "categories": [...], "series": [{"name": "...", "values": [...]}], "note": "...", "wide": false}],
  "tables": [{"title": "...", "columns": [...], "rows": [[...]], "total": [...]}],
  "sections": [{"heading": "ผลสำเร็จ", "bullets": ["..."]}],
  "source": "ที่มาของข้อมูล", "footer_right": "ชื่อหน่วยงาน" }
ทุกกราฟมีตารางข้อมูลประกอบ (กด "ดูข้อมูล") และชี้เมาส์ที่แท่งกราฟเพื่อดูค่า
"""
import json, sys, os, html, math
C = ["#2F5BD3", "#0E9F9A", "#F2A33A", "#8A6FD1", "#E0607E", "#5B8DEF"]
E = html.escape
def fmt(v):
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return f"{v:,.0f}" if float(v).is_integer() else f"{v:,.2f}".rstrip("0").rstrip(".")
    return str(v)

def column(ch, w=520, h=260):
    h = h if w <= 600 else 300
    cats, ser = ch["categories"], ch["series"]; n, k = len(cats), len(ser)
    vmax = max(max(s["values"]) for s in ser) * 1.15 or 1
    top, bot, left = 20, 38, 10; ph = h - top - bot; gw = (w - 2 * left) / n; bw = min(46, gw * 0.72 / k)
    o = [f'<svg viewBox="0 0 {w} {h}" role="img" aria-label="{E(ch["title"])}">',
         f'<line x1="{left}" y1="{top+ph}" x2="{w-left}" y2="{top+ph}" stroke="#C9D3E6"/>']
    for i, c in enumerate(cats):
        cx = left + gw * i + gw / 2
        for j, s in enumerate(ser):
            v = s["values"][i]; bh = ph * v / vmax; x = cx - bw * k / 2 + bw * j
            o.append(f'<g><title>{E(str(c))} · {E(s["name"])}: {fmt(v)} {E(ch.get("unit",""))}</title>'
                     f'<rect x="{x:.1f}" y="{top+ph-bh:.1f}" width="{bw-4:.1f}" height="{bh:.1f}" rx="4" fill="{C[j%6]}"/></g>')
            o.append(f'<text x="{x+(bw-4)/2:.1f}" y="{top+ph-bh-6:.1f}" class="vl">{fmt(v)}</text>')
        o.append(f'<text x="{cx:.1f}" y="{h-12}" class="cl">{E(str(c))}</text>')
    return "".join(o) + "</svg>"

def hbar(ch, w=520, h=None):
    cats, vals = ch["categories"], ch["series"][0]["values"]; n = len(cats)
    rowh = 26; h = h or n * rowh + 10; vmax = max(vals) or 1; lab = max(70, min(170, max(len(str(c)) for c in cats) * 9))
    o = [f'<svg viewBox="0 0 {w} {h}" role="img" aria-label="{E(ch["title"])}">']
    for i, (c, v) in enumerate(zip(cats, vals)):
        y = 5 + i * rowh; bw = (w - lab - 80) * v / vmax
        o.append(f'<text x="{lab-8}" y="{y+rowh*0.66:.1f}" class="hl">{E(str(c))}</text>')
        o.append(f'<g><title>{E(str(c))}: {fmt(v)} {E(ch.get("unit",""))}</title><rect x="{lab}" y="{y+4:.1f}" width="{bw:.1f}" height="{rowh-8}" rx="4" fill="{C[0] if not ch.get("multicolor") else C[i%6]}"/></g>')
        o.append(f'<text x="{lab+bw+6:.1f}" y="{y+rowh*0.66:.1f}" class="hv">{fmt(v)}</text>')
    return "".join(o) + "</svg>"

def line(ch, w=520, h=260):
    h = h if w <= 600 else 300
    cats, ser = ch["categories"], ch["series"]; n = len(cats)
    allv = [v for s in ser for v in s["values"]]; vmin, vmax = min(allv), max(allv)
    pad = (vmax - vmin) * 0.25 or 1; lo, hi = vmin - pad, vmax + pad
    top, bot, left, right = 24, 38, 30, 30; ph = h - top - bot; pw = w - left - right
    X = lambda i: left + (pw * i / (n - 1) if n > 1 else pw / 2); Y = lambda v: top + ph * (1 - (v - lo) / (hi - lo))
    o = [f'<svg viewBox="0 0 {w} {h}" role="img" aria-label="{E(ch["title"])}">',
         f'<line x1="{left}" y1="{top+ph}" x2="{w-right}" y2="{top+ph}" stroke="#C9D3E6"/>']
    for j, s in enumerate(ser):
        pts = " ".join(f"{X(i):.1f},{Y(v):.1f}" for i, v in enumerate(s["values"]))
        o.append(f'<polyline points="{pts}" fill="none" stroke="{C[j%6]}" stroke-width="3"/>')
        for i, v in enumerate(s["values"]):
            o.append(f'<g><title>{E(str(cats[i]))} · {E(s["name"])}: {fmt(v)} {E(ch.get("unit",""))}</title><circle cx="{X(i):.1f}" cy="{Y(v):.1f}" r="5" fill="#fff" stroke="{C[j%6]}" stroke-width="3"/></g>')
            o.append(f'<text x="{X(i):.1f}" y="{Y(v)-11:.1f}" class="vl">{fmt(v)}</text>')
    for i, c in enumerate(cats):
        o.append(f'<text x="{X(i):.1f}" y="{h-12}" class="cl">{E(str(c))}</text>')
    return "".join(o) + "</svg>"

def donut(ch, w=680, h=260):
    cats, vals = ch["categories"], ch["series"][0]["values"]; tot = sum(vals) or 1
    cx, cy, r, rw = 120, h / 2, 92, 34; a = -math.pi / 2; o = [f'<svg viewBox="0 0 {w} {h}" role="img" aria-label="{E(ch["title"])}">']
    for i, (c, v) in enumerate(zip(cats, vals)):
        b = a + 2 * math.pi * v / tot; large = 1 if b - a > math.pi else 0
        x1, y1, x2, y2 = cx + r * math.cos(a), cy + r * math.sin(a), cx + r * math.cos(b), cy + r * math.sin(b)
        o.append(f'<g><title>{E(str(c))}: {fmt(v)} {E(ch.get("unit",""))} ({v/tot*100:.1f}%)</title>'
                 f'<path d="M{x1:.1f},{y1:.1f} A{r},{r} 0 {large} 1 {x2:.1f},{y2:.1f}" fill="none" stroke="{C[i%6]}" stroke-width="{rw}"/></g>')
        a = b
    o.append(f'<text x="{cx}" y="{cy+8}" class="dt">{fmt(tot)}</text>')
    for i, (c, v) in enumerate(zip(cats, vals)):
        y = 40 + i * 30
        o.append(f'<rect x="250" y="{y-13}" width="16" height="16" rx="3" fill="{C[i%6]}"/><text x="274" y="{y}" class="lg">{E(str(c))} · {fmt(v)} ({v/tot*100:.1f}%)</text>')
    return "".join(o) + "</svg>"

def legend(ch):
    if ch["kind"] in ("hbar", "donut") or len(ch["series"]) < 2: return ""
    return '<div class="legend">' + "".join(f'<span><i style="background:{C[j%6]}"></i>{E(s["name"])}</span>' for j, s in enumerate(ch["series"])) + "</div>"

def datatable(ch):
    head = "<tr><th>" + E(ch.get("axis", "รายการ")) + "</th>" + "".join(f"<th>{E(s['name'])}</th>" for s in ch["series"]) + "</tr>"
    rows = "".join("<tr><td>" + E(str(c)) + "</td>" + "".join(f"<td class=n>{fmt(s['values'][i])}</td>" for s in ch["series"]) + "</tr>" for i, c in enumerate(ch["categories"]))
    return f'<details><summary>ดูข้อมูล</summary><table>{head}{rows}</table></details>'

def table(t):
    head = "<tr>" + "".join(f"<th>{E(str(c))}</th>" for c in t["columns"]) + "</tr>"
    num = lambda v: isinstance(v, (int, float))
    body = "".join("<tr>" + "".join(f"<td{' class=n' if num(v) else ''}>{fmt(v)}</td>" for v in r) + "</tr>" for r in t["rows"])
    tot = ("<tr class=tot>" + "".join(f"<td{' class=n' if num(v) else ''}>{fmt(v)}</td>" for v in t["total"]) + "</tr>") if t.get("total") else ""
    return f'<section class="card wide"><h2>{E(t["title"])}</h2><div class="tw"><table>{head}{body}{tot}</table></div></section>'

CSS = """
*{box-sizing:border-box}body{margin:0;background:#F3F6FB;color:#1D2433;font-family:'Sarabun','TH Sarabun New','TH SarabunPSK','Noto Sans Thai','Leelawadee UI',Tahoma,sans-serif;font-size:17px;line-height:1.5}
header{background:linear-gradient(120deg,#14306B,#2F5BD3 60%,#0E9F9A);color:#fff;padding:22px 28px}
header .top{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap}
header h1{margin:0;font-size:30px;line-height:1.3}header p{margin:4px 0 0;opacity:.9}
.badge{background:rgba(255,255,255,.18);border:1px solid rgba(255,255,255,.4);border-radius:999px;padding:4px 14px;font-weight:600;white-space:nowrap}
.btn{margin-top:8px;background:#fff;color:#14306B;border:0;border-radius:8px;padding:6px 14px;font:600 15px inherit;cursor:pointer;font-family:inherit}
main{max-width:1240px;margin:0 auto;padding:20px 20px 32px}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px;margin-bottom:16px}
.kpi{background:#fff;border-radius:14px;padding:16px 18px;border-top:5px solid #2F5BD3;box-shadow:0 2px 8px rgba(20,48,107,.07)}
.kpi.good{border-top-color:#0E9F9A}.kpi.warn{border-top-color:#F2A33A}
.kpi .v{font-size:36px;font-weight:700;color:#14306B;line-height:1.15}.kpi .l{font-weight:600}.kpi .nt{color:#5A6478;font-size:15px}
.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}
.card{background:#fff;border-radius:14px;padding:16px 18px;box-shadow:0 2px 8px rgba(20,48,107,.07);min-width:0}.card.wide{grid-column:1/-1}
.card h2{margin:0 0 6px;font-size:19px;color:#14306B}.card .note{color:#5A6478;font-size:14px;margin:6px 0 0}
svg{width:100%;height:auto;display:block}svg text{font-family:inherit}
.vl{font-size:13px;font-weight:700;text-anchor:middle;fill:#1D2433}.cl{font-size:13px;text-anchor:middle;fill:#5A6478}
.hl{font-size:13px;text-anchor:end;fill:#1D2433}.hv{font-size:13px;font-weight:700;fill:#1D2433}.dt{font-size:30px;font-weight:700;text-anchor:middle;fill:#14306B}.lg{font-size:14px;fill:#1D2433}
.legend{display:flex;gap:16px;flex-wrap:wrap;font-size:14px;color:#5A6478;margin-top:4px}.legend i{display:inline-block;width:12px;height:12px;border-radius:3px;margin-right:6px;vertical-align:-1px}
details{margin-top:8px}summary{cursor:pointer;color:#2F5BD3;font-weight:600;font-size:15px}
.tw{overflow-x:auto}table{border-collapse:collapse;width:100%;font-size:15px;margin-top:6px}th{background:#14306B;color:#fff;text-align:left;padding:6px 10px;font-weight:600}
td{border-bottom:1px solid #E1E7F2;padding:6px 10px}td.n{text-align:right;font-variant-numeric:tabular-nums}tr.tot td{font-weight:700;background:#EAF0FB}
.sections{display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px;margin-top:16px}
.sec h3{margin:0 0 6px;color:#0E7490;font-size:18px}.sec ul{margin:0;padding-left:20px}
footer{max-width:1240px;margin:0 auto;padding:0 20px 24px;color:#5A6478;font-size:14px;display:flex;justify-content:space-between;gap:12px;flex-wrap:wrap}
@media (max-width:760px){.grid{grid-template-columns:1fr}header h1{font-size:24px}}
@media print{body{background:#fff}.btn,summary{display:none}details{display:none}.card,.kpi{box-shadow:none;border:1px solid #DDE3EE}@page{size:A4 landscape;margin:10mm}}
"""

def build(src, out):
    d = json.load(open(src, encoding="utf-8"))
    kp = "".join(f'<div class="kpi {E(k.get("status",""))}"><div class="v">{E(str(k["value"]))}</div><div class="l">{E(k["label"])}</div><div class="nt">{E(k.get("note",""))}</div></div>' for k in d["kpis"])
    cards = []
    for ch in d.get("charts", []):
        fn = {"column": column, "bar": column, "hbar": hbar, "line": line, "donut": donut}[ch["kind"]]
        svg = fn(ch, w=1160) if ch.get("wide") else fn(ch)
        note = f'<p class="note">{E(ch["note"])}</p>' if ch.get("note") else ""
        cards.append(f'<section class="card{" wide" if ch.get("wide") else ""}"><h2>{E(ch["title"])}</h2>{legend(ch)}{svg}{note}{datatable(ch)}</section>')
    tables = "".join(table(t) for t in d.get("tables", []))
    secs = "".join(f'<section class="card sec"><h3>{E(s["heading"])}</h3><ul>' + "".join(f"<li>{E(b)}</li>" for b in s["bullets"]) + "</ul></section>" for s in d.get("sections", []))
    page = f"""<!doctype html><html lang="th"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{E(d["title"])}</title><style>{CSS}</style></head><body>
<header><div class="top"><div><h1>{E(d["title"])}</h1><p>{E(d.get("subtitle",""))}</p></div>
<div style="text-align:right"><span class="badge">{E(d.get("badge",""))}</span><br><button class="btn" onclick="window.print()">พิมพ์ / บันทึก PDF</button></div></div></header>
<main><div class="kpis">{kp}</div><div class="grid">{"".join(cards)}{tables}</div><div class="sections">{secs}</div></main>
<footer><span>ที่มา: {E(d.get("source",""))} · {E(d.get("updated",""))}</span><span>{E(d.get("footer_right",""))}</span></footer>
</body></html>"""
    os.makedirs(os.path.dirname(os.path.abspath(out)) or ".", exist_ok=True)
    open(out, "w", encoding="utf-8").write(page)
    print("สร้าง Dashboard แล้ว:", out, f"({len(d['kpis'])} KPI, {len(cards)} กราฟ, {len(d.get('tables', []))} ตาราง)")

if __name__ == "__main__":
    if len(sys.argv) < 3: print(__doc__); sys.exit(1)
    build(sys.argv[1], sys.argv[2])
