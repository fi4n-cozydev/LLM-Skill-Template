#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_onepage.py — สร้าง One Page (A4 แนวตั้ง) แบบ Infographic จาก onepage.json แล้วแปลงเป็น PDF
วิธีใช้:  python build_onepage.py onepage.json output/onepage.html
ผลลัพธ์: onepage.html และ onepage.pdf (ถ้าเครื่องมี Playwright หรือ Google Chrome / Microsoft Edge)
ถ้าสร้าง PDF ไม่ได้: เปิด onepage.html ในเบราว์เซอร์ กด Ctrl+P → Save as PDF (ขนาด A4, ระยะขอบ None)

โครงสร้าง onepage.json
{ "title": "...", "subtitle": "...", "badge": "ปีงบประมาณ 2569",
  "kpis": [{"value": "120", "label": "ผู้เข้าอบรม (คน)", "note": "เป้าหมาย 100"}],           # 3–4 ค่า
  "charts": [{"kind": "bar|hbar|pair", "title": "...", "unit": "คน", "categories": [...],
              "series": [{"name": "...", "values": [...]}]}],                                  # 1–2 กราฟ
  "sections": [{"heading": "ผลสำเร็จ", "bullets": ["..."]}],                                  # 2–3 กล่อง
  "source": "ที่มาของข้อมูล" }
"""
import json, sys, os, html, shutil, subprocess
C = ["#2F5BD3", "#0E9F9A", "#F2A33A", "#8A6FD1"]
E = html.escape

def svg_bars(ch, w=340, h=185):
    cats = ch["categories"]; ser = ch["series"]; n = len(cats); k = len(ser)
    vmax = max(max(s["values"]) for s in ser) * 1.15 or 1
    top, bot, left = 18, 34, 8; ph = h - top - bot; gw = (w - left * 2) / n; bw = min(34, gw * 0.7 / k)
    out = [f'<svg viewBox="0 0 {w} {h}" width="100%" role="img" aria-label="{E(ch.get("title",""))}">']
    out.append(f'<line x1="{left}" y1="{top+ph}" x2="{w-left}" y2="{top+ph}" stroke="#C9D3E6"/>')
    for i, c in enumerate(cats):
        cx = left + gw * i + gw / 2
        for j, s in enumerate(ser):
            v = s["values"][i]; bh = ph * v / vmax; x = cx - bw * k / 2 + bw * j
            out.append(f'<rect x="{x:.1f}" y="{top+ph-bh:.1f}" width="{bw-3:.1f}" height="{bh:.1f}" rx="3" fill="{C[j%4]}"/>')
            out.append(f'<text x="{x+(bw-3)/2:.1f}" y="{top+ph-bh-4:.1f}" font-size="12" text-anchor="middle" fill="#1D2433" font-weight="700">{v:g}</text>')
        out.append(f'<text x="{cx:.1f}" y="{h-12}" font-size="12.5" text-anchor="middle" fill="#5A6478">{E(str(c))}</text>')
    out.append("</svg>")
    return "".join(out)

def svg_hbar(ch, w=340, h=185):
    cats = ch["categories"]; vals = ch["series"][0]["values"]; n = len(cats)
    vmax = max(vals) or 1; rowh = (h - 10) / n; lab = 70
    out = [f'<svg viewBox="0 0 {w} {h}" width="100%" role="img" aria-label="{E(ch.get("title",""))}">']
    for i, (c, v) in enumerate(zip(cats, vals)):
        y = 5 + i * rowh; bw = (w - lab - 62) * v / vmax
        out.append(f'<text x="{lab-6}" y="{y+rowh*0.68:.1f}" font-size="12.5" text-anchor="end" fill="#1D2433">{E(str(c))}</text>')
        out.append(f'<rect x="{lab}" y="{y+rowh*0.18:.1f}" width="{bw:.1f}" height="{rowh*0.64:.1f}" rx="3" fill="{C[i%4] if ch.get("multicolor") else C[0]}"/>')
        out.append(f'<text x="{lab+bw+5:.1f}" y="{y+rowh*0.68:.1f}" font-size="12.5" fill="#1D2433" font-weight="700">{v:,g}</text>')
    out.append("</svg>")
    return "".join(out)

def legend(ch):
    if len(ch["series"]) < 2: return ""
    return '<div class="lg">' + "".join(f'<span><i style="background:{C[j%4]}"></i>{E(s["name"])}</span>' for j, s in enumerate(ch["series"])) + "</div>"

CSS = """
@page{size:A4;margin:0}*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'TH SarabunPSK','TH Sarabun New','Sarabun',sans-serif;color:#1D2433;background:#E9EDF5}
.page{width:210mm;height:297mm;margin:0 auto;background:#fff;padding:12mm 12mm 10mm;display:flex;flex-direction:column;gap:5mm;overflow:hidden}
header{background:linear-gradient(120deg,#14306B,#1E46A8 65%,#0E9F9A);color:#fff;border-radius:5mm;padding:6mm 8mm;position:relative}
header h1{font-size:25pt;line-height:1.1;padding-right:42mm}header p{font-size:14pt;opacity:.92;margin-top:1.5mm}
.badge{position:absolute;right:6mm;top:6mm;white-space:nowrap;background:rgba(255,255,255,.18);border:1px solid rgba(255,255,255,.5);border-radius:20mm;padding:1mm 4mm;font-size:13pt}
.kpis{display:grid;grid-template-columns:repeat(var(--n),1fr);gap:4mm}
.kpi{background:#E8F0FD;border-radius:4mm;padding:4mm;border-top:2mm solid var(--c)}
.kpi b{display:block;font-size:26pt;line-height:1;color:var(--c)}.kpi span{display:block;font-size:13.5pt;font-weight:700;color:#14306B;margin-top:1mm;line-height:1.2}.kpi small{display:block;font-size:11.5pt;color:#5A6478;line-height:1.25;margin-top:1mm}
.charts{display:grid;grid-template-columns:repeat(var(--m),1fr);gap:4mm}
.card{border:1px solid #D6DEEC;border-radius:4mm;padding:4mm}
.card h2{font-size:14pt;line-height:1.2;color:#14306B;margin-bottom:1mm}
.lg{display:flex;gap:4mm;font-size:12.5pt;color:#5A6478;margin-top:1mm}.lg i{display:inline-block;width:3mm;height:3mm;border-radius:1mm;margin-right:1.5mm}
.secs{display:grid;grid-template-columns:repeat(var(--s),1fr);gap:4mm;flex:1;min-height:0}
.sec{background:#F6F8FC;border-radius:4mm;padding:4mm 5mm;border-left:2mm solid var(--c)}
.sec h3{font-size:15pt;color:#14306B;margin-bottom:1.5mm}.sec li{font-size:12.5pt;line-height:1.3;margin:0 0 1.2mm 4.5mm}
footer{font-size:11pt;color:#5A6478;border-top:1px solid #D6DEEC;padding-top:2mm;display:flex;justify-content:space-between}
@media screen{.page{margin:8mm auto;box-shadow:0 2mm 8mm rgba(0,0,0,.15)}}
"""

def build(spec, out_html):
    k = spec.get("kpis", [])[:4]; ch = spec.get("charts", [])[:2]; sec = spec.get("sections", [])[:3]
    kp = "".join(f'<div class="kpi" style="--c:{C[i%4]}"><b>{E(str(x["value"]))}</b><span>{E(x.get("label",""))}</span><small>{E(x.get("note",""))}</small></div>' for i, x in enumerate(k))
    cs = "".join(f'<div class="card"><h2>{E(c.get("title",""))}</h2>{svg_hbar(c) if c.get("kind")=="hbar" else svg_bars(c)}{legend(c)}</div>' for c in ch)
    ss = "".join(f'<div class="sec" style="--c:{C[i%4]}"><h3>{E(s["heading"])}</h3><ul>' + "".join(f"<li>{E(b)}</li>" for b in s.get("bullets", [])) + "</ul></div>" for i, s in enumerate(sec))
    doc = f"""<!doctype html><html lang="th"><head><meta charset="utf-8"><title>{E(spec.get('title',''))}</title>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Sarabun:wght@400;700&display=swap"><style>{CSS}</style></head>
<body><div class="page"><header><h1>{E(spec.get('title',''))}</h1><p>{E(spec.get('subtitle',''))}</p>{f'<span class="badge">{E(spec["badge"])}</span>' if spec.get('badge') else ''}</header>
<section class="kpis" style="--n:{max(len(k),1)}">{kp}</section><section class="charts" style="--m:{max(len(ch),1)}">{cs}</section>
<section class="secs" style="--s:{max(len(sec),1)}">{ss}</section><footer><span>ที่มา: {E(spec.get('source',''))}</span><span>{E(spec.get('footer_right',''))}</span></footer></div></body></html>"""
    open(out_html, "w", encoding="utf-8").write(doc)
    return out_html

def to_pdf(html_path):
    pdf = os.path.splitext(html_path)[0] + ".pdf"; url = "file://" + os.path.abspath(html_path)
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as p:
            b = p.chromium.launch(); pg = b.new_page(); pg.goto(url); pg.wait_for_timeout(800)
            pg.pdf(path=pdf, format="A4", print_background=True, margin={"top": "0", "bottom": "0", "left": "0", "right": "0"}); b.close()
        return pdf
    except Exception:
        pass
    for exe in ("google-chrome", "chrome", "chromium", "chromium-browser", "msedge", "microsoft-edge",
                r"C:\Program Files\Google\Chrome\Application\chrome.exe", r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
                "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"):
        path = shutil.which(exe) or (exe if os.path.exists(exe) else None)
        if path:
            subprocess.run([path, "--headless", "--disable-gpu", "--no-pdf-header-footer", f"--print-to-pdf={pdf}", url],
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if os.path.exists(pdf): return pdf
    return None

if __name__ == "__main__":
    if len(sys.argv) < 3: print(__doc__); sys.exit(1)
    spec = json.load(open(sys.argv[1], encoding="utf-8"))
    h = build(spec, sys.argv[2]); print("สร้าง One Page แล้ว:", h)
    p = to_pdf(h)
    print("PDF:", p if p else "สร้างอัตโนมัติไม่ได้ — เปิดไฟล์ HTML แล้วกด Ctrl+P → Save as PDF (A4, ระยะขอบ None)")
