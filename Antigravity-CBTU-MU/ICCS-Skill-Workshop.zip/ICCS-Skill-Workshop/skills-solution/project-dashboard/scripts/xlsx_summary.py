#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""xlsx_summary.py — อ่านไฟล์ Excel ทุกชีตแล้วพิมพ์เป็นตาราง Markdown พร้อมผลรวม/ค่าเฉลี่ยของคอลัมน์ตัวเลข
ใช้ก่อนเขียนสไลด์ เพื่อให้ตัวเลขทุกค่ามาจากไฟล์จริง (ห้ามคำนวณในหัว)
วิธีใช้: python xlsx_summary.py input/training-data.xlsx > output/data-summary.md
"""
import sys
from openpyxl import load_workbook
wb = load_workbook(sys.argv[1], data_only=True)
for ws in wb.worksheets:
    rows = [[c for c in r] for r in ws.iter_rows(values_only=True) if any(v is not None for v in r)]
    if not rows: continue
    head, body = rows[0], rows[1:]
    print(f"\n## ชีต: {ws.title}\n")
    print("| " + " | ".join(str(h) for h in head) + " |"); print("|" + "---|" * len(head))
    for r in body: print("| " + " | ".join("" if v is None else (f"{v:,}" if isinstance(v, (int, float)) else str(v)) for v in r) + " |")
    data = [r for r in body if not str(r[0]).startswith("รวม")]
    stats = []
    for j, h in enumerate(head):
        vals = [r[j] for r in data if isinstance(r[j], (int, float))]
        if vals and len(vals) == len(data):
            stats.append(f"- {h}: รวม {sum(vals):,.2f} · เฉลี่ย {sum(vals)/len(vals):,.2f} · ต่ำสุด {min(vals):,} · สูงสุด {max(vals):,}")
    wcol = next((j for j, h in enumerate(head) if h and "(คน)" in str(h)), None)
    if wcol is not None:
        wts = [r[wcol] for r in data]
        for j, h in enumerate(head):
            if j == wcol or not h or "(คน)" in str(h) or "(ร้าน)" in str(h) or "(บาท)" in str(h): continue
            vals = [r[j] for r in data]
            if all(isinstance(v, (int, float)) for v in vals) and all(isinstance(w, (int, float)) for w in wts) and sum(wts):
                stats.append(f"- {h}: เฉลี่ยถ่วงน้ำหนักด้วย '{head[wcol]}' = {sum(v*w for v, w in zip(vals, wts))/sum(wts):,.2f}  ← ใช้ค่านี้เป็นค่าเฉลี่ยรวม")
    if stats:
        print(f"\nสถิติ (ไม่รวมแถว 'รวม', {len(data)} แถว):"); print("\n".join(stats))
