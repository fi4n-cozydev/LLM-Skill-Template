---
name: project-dashboard
description: จัดทำรายงานผลการดำเนินโครงการเป็น One Page A4 (PDF) และ Dashboard (HTML) จากรายงานโครงการและไฟล์ข้อมูล Excel โดยตัวเลขทุกค่าตรวจสอบย้อนกลับได้ ใช้เมื่อผู้ใช้ขอ "One Page" "Dashboard" "สรุปผลการดำเนินโครงการ" หรือ "รายงานผลโครงการให้ผู้บริหาร"
---
# Skill One Page และ Dashboard ผลการดำเนินโครงการ

> เส้นทาง `scripts/` `references/` `assets/` ในไฟล์นี้อยู่ในโฟลเดอร์ของ Skill (`.agents/skills/project-dashboard/`) ส่วน `input/` และ `output/` อยู่ในโฟลเดอร์โปรเจกต์

## วัตถุประสงค์
สรุปผลการดำเนินโครงการให้ผู้บริหารเห็นภาพรวมได้ทันที ทั้งฉบับพิมพ์ (One Page) และฉบับเปิดบนจอ (Dashboard) รูปแบบเดียวกับงานปีก่อน

## เงื่อนไขการใช้งาน
- Input: รายงานโครงการ (.md/.docx) และไฟล์ข้อมูล (.xlsx) อ้างถึงด้วย @
- หากไม่มีไฟล์ข้อมูลหรือรายงาน ให้ขอจากผู้ใช้ก่อน ไม่สร้างตัวเลขขึ้นเอง

## คำแนะนำ
1. สรุปข้อมูล: `python scripts/xlsx_summary.py [ไฟล์.xlsx] > output/data-summary.md` แล้วอ่านคู่กับรายงาน
2. เสนอ KPI 4–6 ค่า และรายการกราฟให้ผู้ใช้พิจารณาในแชต
3. เขียน output/onepage.json แล้วรัน `python scripts/build_onepage.py output/onepage.json output/onepage.html` (ได้ onepage.pdf)
4. เขียน output/dashboard.json แล้วรัน `python scripts/build_dashboard.py output/dashboard.json output/dashboard.html`
5. จัดทำ output/number-check.md: ตัวเลข | ใช้ที่ใด | ที่มา (ชีต/บรรทัด) | วิธีคำนวณ
6. เปิดไฟล์ตรวจตาม Checklist แล้วสรุปให้ผู้ใช้

## กฎ
- ตัวเลขทุกค่ามาจาก data-summary.md หรือรายงาน คำนวณด้วย Python ค่าเฉลี่ยรวมใช้ค่าเฉลี่ยถ่วงน้ำหนัก
- ข้อความในกล่องผลสำเร็จ อุปสรรค และขั้นต่อไป มาจากรายงานเท่านั้น
- ใช้เครื่องมือใน scripts/ เพื่อให้รูปแบบตรงตาม references/design-rules.md
- ระบุแหล่งข้อมูลและวันที่ของข้อมูลทุกครั้ง

## รูปแบบไฟล์ผลลัพธ์
- One Page: A4 แนวตั้ง 1 หน้าพอดี
- Dashboard: HTML ไฟล์เดียว เปิดได้โดยไม่ต้องต่ออินเทอร์เน็ต ทุกกราฟมีตารางข้อมูลประกอบ

## ผลลัพธ์
- output/onepage.pdf · output/dashboard.html · output/number-check.md (และไฟล์ .json ที่ใช้สร้าง)

## Checklist คุณภาพ
- [ ] KPI ตรงกับข้อมูลและมีการเทียบกับเป้าหมาย
- [ ] ตัวเลขทุกค่าอยู่ใน number-check.md พร้อมที่มา
- [ ] One Page เป็น 1 หน้า A4 ข้อความไม่ล้น
- [ ] Dashboard แสดงผลได้บนจอคอมพิวเตอร์และโทรศัพท์
