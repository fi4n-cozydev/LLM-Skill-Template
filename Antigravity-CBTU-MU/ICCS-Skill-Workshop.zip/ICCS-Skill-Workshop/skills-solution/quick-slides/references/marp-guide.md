# คู่มือย่อ Marp และธีม Mahidol

## การแปลงเป็น PDF
- คำสั่ง (ต้องมี Node.js และ Chrome หรือ Edge): `npx -y @marp-team/marp-cli@4.5.1 slides.md --theme themes/theme-mahidol.css --html --allow-local-files --pdf -o slides.pdf`
- รันในโฟลเดอร์ของสไลด์ (โฟลเดอร์เดียวกับ slides.md themes/ และ fig/)
- ทางเลือกเมื่อเครื่องไม่มี Node.js: ติดตั้งส่วนขยาย **Marp for VS Code** ใน Antigravity
  ตั้งค่า `markdown.marp.enableHtml` = true และ `markdown.marp.themes` = ["./themes/theme-mahidol.css"]
  แล้วเปิด slides.md → คำสั่ง Marp: Export Slide Deck → PDF

## โครงหน้าในแม่แบบ
| หน้า | class / องค์ประกอบ |
|---|---|
| ปก | `<!-- _class: lead -->` ตรา `university-logo` หัวเรื่อง `#` และ `subtitle` |
| ประเด็นหลัก 3 ข้อ | `visual-grid` + `visual-card` 3 ใบ (ใบที่ 3 ใช้ `visual-card ai`) |
| ตัวเลขเด่น | `big` (value / unit / desc) และ `diagram-caption` สำหรับแหล่งที่มา |
| เปรียบเทียบ | `visual-grid two` 2 ใบ รายการละ 3 ข้อ |
| สรุป | รายการลำดับ 3 ข้อ และกล่อง `action` |

## ฟอนต์
- ธีมใช้ Noto Sans Thai (สำรอง Sarabun) และโหลดจาก Google Fonts เมื่อเครื่องออนไลน์
- หากฟอนต์ใน PDF ไม่ถูกต้อง ให้ติดตั้ง Noto Sans Thai หรือ Sarabun จาก fonts.google.com แล้วแปลงใหม่
