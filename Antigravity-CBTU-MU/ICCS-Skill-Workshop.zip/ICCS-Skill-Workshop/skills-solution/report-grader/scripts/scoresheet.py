#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
scoresheet.py — แบบบันทึกคะแนนรายงาน (Excel) และการกรอกคะแนนที่ AI เสนอ

สร้างแบบบันทึกคะแนนเปล่า:
    python scoresheet.py template <setup.json> <scoresheet.xlsx>
กรอกคะแนนที่ AI เสนอลงสำเนาของแบบบันทึกคะแนน:
    python scoresheet.py fill <scoresheet.xlsx ต้นฉบับ> <scores.json> <ไฟล์ผลลัพธ์.xlsx>

โครงสร้าง scores.json (Agent เขียนหลังตรวจรายงาน)
{"scores": [{"id": "6505010101", "criterion": "C1", "score": 18,
             "reason": "...", "where": "หัวข้อ 3 SWOT Analysis — “ข้อความที่พบ”"}],
 "comments": {"6505010101": {"strengths": "...", "improvements": "..."}}}
"""
import json, sys, shutil
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.formatting.rule import FormulaRule
from openpyxl.utils import get_column_letter as L

F = "TH SarabunPSK"; NAVY = "1F3A6E"; AI_FILL = "E8F0FB"; T_FILL = "FFF4D6"; SUM_FILL = "E3F4EA"
thin = Side(style="thin", color="9AA8BD"); BOX = Border(top=thin, bottom=thin, left=thin, right=thin)
SHEET, SUMMARY = "บันทึกคะแนน", "สรุปคะแนน"
COLS = ["รหัสนักศึกษา", "ชื่อ-สกุล", "เกณฑ์", "คะแนนเต็ม",
        "คะแนนที่ AI เสนอ", "เหตุผล", "จุดในรายงาน (หัวข้อ — ข้อความที่พบ)",
        "คะแนนอาจารย์ (กรอกเมื่อต้องการแก้)", "หมายเหตุอาจารย์", "คะแนนสุดท้าย"]
WID = [15, 26, 30, 10, 11, 50, 48, 15, 32, 11]

def font(b=False, c="1D2433", s=16): return Font(name=F, size=s, bold=b, color=c)
def cell(ws, r, c, v, fill=None, bold=False, color="1D2433", center=False, wrap=True):
    x = ws.cell(row=r, column=c, value=v); x.font = font(bold, color); x.border = BOX
    x.alignment = Alignment(wrap_text=wrap, vertical="top", horizontal="center" if center else None)
    if fill: x.fill = PatternFill("solid", fgColor=fill)
    return x

def page(ws, landscape=True):
    ws.page_setup.orientation = "landscape" if landscape else "portrait"; ws.page_setup.paperSize = ws.PAPERSIZE_A4
    ws.page_setup.fitToWidth = 1; ws.page_setup.fitToHeight = 0; ws.sheet_properties.pageSetUpPr.fitToPage = True
    ws.page_margins.left = ws.page_margins.right = 0.4; ws.page_margins.top = ws.page_margins.bottom = 0.5
    ws.sheet_view.zoomScale = 90

def template(setup_path, out):
    st = json.load(open(setup_path, encoding="utf-8")); rub = st["rubric"]; studs = st["students"]
    wb = Workbook()
    # ---------------- คำชี้แจง
    ws = wb.active; ws.title = "คำชี้แจง"; ws.column_dimensions["A"].width = 120
    lines = [(f"แบบบันทึกคะแนน {st['assignment']}", True, 20),
             (f"{st['course']} · ภาคการศึกษา {st['term']} · คะแนนเต็ม {sum(x['max'] for x in rub)}", True, 16),
             ("", False, 16),
             ("ช่องสีฟ้า  = AI กรอก: คะแนนที่เสนอ เหตุผล และจุดในรายงานที่ใช้เป็นหลักฐาน", False, 16),
             ("ช่องสีเหลือง = อาจารย์กรอก: ถ้าเห็นด้วยกับคะแนนที่ AI เสนอ ไม่ต้องกรอก · ถ้าไม่เห็นด้วย ให้กรอกคะแนนอาจารย์และหมายเหตุ", False, 16),
             ("คะแนนสุดท้าย = คะแนนอาจารย์ (ถ้ามี) มิฉะนั้นใช้คะแนนที่ AI เสนอ", False, 16),
             ("เมื่อตรวจทานนักศึกษาคนใดครบแล้ว ให้เลือก \"ตรวจทานแล้ว\" ในชีต สรุปคะแนน — ระบบจะออกรายงานผลฉบับจริงเฉพาะคนที่ตรวจทานแล้ว", False, 16),
             ("หาข้อความในรายงานได้รวดเร็วด้วย Ctrl+F แล้ววางข้อความที่อยู่ในเครื่องหมายคำพูดจากช่อง จุดในรายงาน", False, 16)]
    for i, (t, b, s) in enumerate(lines, 1):
        c = ws.cell(row=i, column=1, value=t); c.font = font(b, NAVY if b else "1D2433", s)
        c.alignment = Alignment(wrap_text=True, vertical="top")
    ws.cell(row=4, column=1).fill = PatternFill("solid", fgColor=AI_FILL)
    ws.cell(row=5, column=1).fill = PatternFill("solid", fgColor=T_FILL)
    r0 = len(lines) + 2
    ws.cell(row=r0, column=1, value="เกณฑ์การให้คะแนน").font = font(True, NAVY)
    for k, x in enumerate(rub, r0 + 1):
        c = ws.cell(row=k, column=1, value=f"{x['id']} {x['name']} ({x['max']} คะแนน): {x['levels']}"); c.font = font()
        c.alignment = Alignment(wrap_text=True, vertical="top")
    page(ws, False)
    # ---------------- บันทึกคะแนน
    w = wb.create_sheet(SHEET)
    w.merge_cells("A1:D1"); w.merge_cells("E1:G1"); w.merge_cells("H1:I1")
    for rng, txt, fill, col in (("A1", "ข้อมูลนักศึกษาและเกณฑ์", NAVY, "FFFFFF"), ("E1", "ส่วนที่ AI กรอก", "2F5BD3", "FFFFFF"),
                                ("H1", "ส่วนที่อาจารย์กรอก", "C98A00", "FFFFFF"), ("J1", "ผล", NAVY, "FFFFFF")):
        c = w[rng]; c.value = txt; c.font = font(True, col); c.fill = PatternFill("solid", fgColor=fill); c.alignment = Alignment(horizontal="center", vertical="center")
    for j, (h, wd) in enumerate(zip(COLS, WID), 1):
        c = cell(w, 2, j, h, NAVY if j < 5 or j == 10 else ("2F5BD3" if j < 8 else "C98A00"), True, "FFFFFF", True)
        c.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center"); w.column_dimensions[L(j)].width = wd
    w.row_dimensions[1].height = 26; w.row_dimensions[2].height = 54
    r = 3
    for s in studs:
        for x in rub:
            vals = [s["id"], s["name"], f"{x['id']} {x['name']}", x["max"], None, None, None, None, None, f'=IF(H{r}="",E{r},H{r})']
            for j, v in enumerate(vals, 1):
                fill = AI_FILL if j in (5, 6, 7) else (T_FILL if j in (8, 9) else None)
                cell(w, r, j, v, fill, j == 10, center=j in (1, 4, 5, 8, 10))
            r += 1
    last = r - 1
    dv = DataValidation(type="decimal", operator="between", formula1="0", formula2="100", allow_blank=True,
                        showErrorMessage=True, error="กรอกคะแนนเป็นตัวเลข ไม่เกินคะแนนเต็มของเกณฑ์")
    w.add_data_validation(dv); dv.add(f"H3:H{last}")
    w.conditional_formatting.add(f"H3:H{last}", FormulaRule(formula=["AND(H3<>\"\",H3>D3)"], fill=PatternFill("solid", fgColor="F8C9C4")))
    w.conditional_formatting.add(f"J3:J{last}", FormulaRule(formula=["AND(H3<>\"\",H3<>E3)"], font=Font(name=F, size=16, bold=True, color="C0392B")))
    w.freeze_panes = "C3"; page(w); w.print_title_rows = "1:2"
    # ---------------- สรุปคะแนน
    sm = wb.create_sheet(SUMMARY)
    head = ["รหัสนักศึกษา", "ชื่อ-สกุล"] + [f"{x['id']} ({x['max']})" for x in rub] + ["รวม", "ร้อยละ", "ตรวจทานแล้ว"]
    for j, h in enumerate(head, 1):
        c = cell(sm, 1, j, h, "C98A00" if h == "ตรวจทานแล้ว" else NAVY, True, "FFFFFF", True); c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        sm.column_dimensions[L(j)].width = {1: 14, 2: 28}.get(j, 11 if j <= 2 + len(rub) else 13)
    sm.row_dimensions[1].height = 34
    R = f"'{SHEET}'!"
    for i, s in enumerate(studs, 2):
        cell(sm, i, 1, s["id"], center=True); cell(sm, i, 2, s["name"])
        for k, x in enumerate(rub, 3):
            cell(sm, i, k, f'=SUMIFS({R}$J$3:$J${last},{R}$A$3:$A${last},$A{i},{R}$C$3:$C${last},"{x["id"]} *")', center=True)
        tc = 3 + len(rub)
        cell(sm, i, tc, f"=SUM({L(3)}{i}:{L(tc-1)}{i})", SUM_FILL, True, center=True)
        cell(sm, i, tc + 1, f"=ROUND({L(tc)}{i}/{sum(x['max'] for x in rub)}*100,1)", center=True)
        cell(sm, i, tc + 2, None, T_FILL, center=True)
    n = len(studs) + 1; rc = 5 + len(rub) - 0
    dv2 = DataValidation(type="list", formula1='"ตรวจทานแล้ว"', allow_blank=True); sm.add_data_validation(dv2)
    dv2.add(f"{L(5 + len(rub))}2:{L(5 + len(rub))}{n}")
    sm.freeze_panes = "C2"; page(sm)
    wb.active = 1
    wb.save(out); print("สร้างแบบบันทึกคะแนน:", out, f"({len(studs)} คน × {len(rub)} เกณฑ์)")

def fill(src, scores_json, out):
    d = json.load(open(scores_json, encoding="utf-8")); shutil.copy(src, out)
    wb = load_workbook(out); w = wb[SHEET]
    idx = {}
    for r in range(3, w.max_row + 1):
        sid, crit = w.cell(r, 1).value, w.cell(r, 3).value
        if sid and crit: idx[(str(sid), str(crit).split()[0])] = r
    miss = []
    for s in d["scores"]:
        r = idx.get((str(s["id"]), s["criterion"]))
        if not r: miss.append(f'{s["id"]}/{s["criterion"]}'); continue
        mx = w.cell(r, 4).value
        if mx is not None and float(s["score"]) > float(mx): raise SystemExit(f'คะแนนเกินคะแนนเต็ม: {s["id"]} {s["criterion"]}')
        w.cell(r, 5).value = s["score"]; w.cell(r, 6).value = s.get("reason", ""); w.cell(r, 7).value = s.get("where", "")
    empty = [f"{w.cell(r,1).value}/{str(w.cell(r,3).value).split()[0]}" for r in idx.values() if w.cell(r, 5).value is None]
    wb.save(out)
    print("กรอกคะแนนที่ AI เสนอแล้ว:", out)
    if miss: print("ไม่พบแถวในแบบบันทึกคะแนน:", ", ".join(miss))
    if empty: print("ยังไม่มีคะแนน:", ", ".join(empty))

if __name__ == "__main__":
    a = sys.argv[1:]
    if len(a) == 3 and a[0] == "template": template(a[1], a[2])
    elif len(a) == 4 and a[0] == "fill": fill(a[1], a[2], a[3])
    else: print(__doc__); sys.exit(1)
