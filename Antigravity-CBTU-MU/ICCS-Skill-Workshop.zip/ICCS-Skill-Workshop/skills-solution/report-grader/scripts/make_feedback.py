#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
make_feedback.py — ออกรายงานผลการตรวจรายบุคคล (.docx + .pdf) จากแบบบันทึกคะแนนที่อาจารย์ตรวจทานแล้ว
- คะแนนสุดท้าย = คะแนนอาจารย์ (ถ้ามี) มิฉะนั้นใช้คะแนนที่ AI เสนอ
- นักศึกษาที่ยังไม่ได้เลือก "ตรวจทานแล้ว" ในชีต สรุปคะแนน จะได้รายงาน "ฉบับร่าง"
วิธีใช้:  python make_feedback.py <scoresheet.xlsx> <scores.json> <โฟลเดอร์ผลลัพธ์> [--course "..."] [--no-pdf]
"""
import json, os, sys, datetime
from openpyxl import load_workbook
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from md_to_docx import convert, to_pdf

TH_M = ["", "มกราคม", "กุมภาพันธ์", "มีนาคม", "เมษายน", "พฤษภาคม", "มิถุนายน", "กรกฎาคม", "สิงหาคม", "กันยายน", "ตุลาคม", "พฤศจิกายน", "ธันวาคม"]
def th_date(d=None): d = d or datetime.date.today(); return f"{d.day} {TH_M[d.month]} {d.year + 543}"
def c(x): return "" if x is None else str(x).replace("|", "/").replace("\n", " ").strip()
def num(x): return f"{float(x):g}"

def main(xlsx, scores_json, outdir, make_pdf=True):
    meta = json.load(open(scores_json, encoding="utf-8")); com = meta.get("comments", {})
    wb = load_workbook(xlsx); w = wb["บันทึกคะแนน"]; sm = wb["สรุปคะแนน"]
    title = str(wb["คำชี้แจง"]["A1"].value or "").replace("แบบบันทึกคะแนน ", ""); sub = str(wb["คำชี้แจง"]["A2"].value or "")
    hdr = [x.value for x in sm[1]]; rv = hdr.index("ตรวจทานแล้ว")
    reviewed = {str(r[0]): (r[rv] == "ตรวจทานแล้ว") for r in sm.iter_rows(min_row=2, values_only=True) if r[0]}
    data = {}
    for r in w.iter_rows(min_row=3, values_only=True):
        if r[0]: data.setdefault(str(r[0]), []).append(r)
    os.makedirs(outdir, exist_ok=True); summary = []
    for sid, rows in data.items():
        name = rows[0][1]; ok = reviewed.get(sid, False); total = tmax = 0; tab = []; det = []; missing = 0
        for (_, _, crit, mx, ai, why, where, tch, note, _) in rows:
            if ai is None and tch in (None, ""): missing += 1; continue
            final = tch if tch not in (None, "") else ai; total += float(final); tmax += float(mx)
            adj = f" (อาจารย์ปรับจาก {num(ai)})" if tch not in (None, "") and ai is not None and float(tch) != float(ai) else ""
            tab.append(f"| {c(crit)} | {num(mx)} | {num(final)}{adj} |")
            det += [f"**{c(crit)} — {num(final)} จาก {num(mx)} คะแนน**", f"เหตุผล: {c(why)}", f"จุดในรายงาน: {c(where)}"]
            if note: det.append(f"หมายเหตุอาจารย์: {c(note)}")
            det.append(" ")
        pct = round(total / tmax * 100, 1) if tmax else 0
        e = com.get(sid, {})
        md = [f"# รายงานผลการตรวจรายงานรายบุคคล{'' if ok else ' (ฉบับร่าง)'}", f"**{title}**{{.center}}", f"{sub}{{.center}}", "---",
              "| รายการ | รายละเอียด |", "|---|---|", f"| ชื่อ-สกุล | {c(name)} |", f"| รหัสนักศึกษา | {sid} |",
              f"| คะแนนรวม | **{num(total)} จาก {num(tmax)} (ร้อยละ {num(pct)})** |",
              f"| สถานะ | {'อาจารย์ผู้สอนตรวจทานแล้ว' if ok else 'ฉบับร่าง รอการตรวจทานของอาจารย์ผู้สอน — ยังไม่ใช่ผลการตรวจอย่างเป็นทางการ'} |",
              "## คะแนนรายเกณฑ์", "| เกณฑ์ | คะแนนเต็ม | คะแนนที่ได้ |", "|---|---|---|", *tab, f"| **รวม** | **{num(tmax)}** | **{num(total)}** |",
              "## เหตุผลการให้คะแนน", *det]
        if e: md += ["## ข้อเสนอแนะ", f"**จุดเด่น:** {c(e.get('strengths'))}", f"**สิ่งที่ควรพัฒนา:** {c(e.get('improvements'))}"]
        md += [" ", f"วันที่ {th_date()}{{.right}}", " ", "(........................................){.sign}", "อาจารย์ผู้สอน{.sign}"]
        base = os.path.join(outdir, f"feedback-{sid}")
        open(base + ".md", "w", encoding="utf-8").write("\n".join(md)); convert("\n".join(md), base + ".docx")
        if make_pdf: to_pdf(base + ".docx")
        summary.append((sid, name, total, tmax, pct, ok))
        print(("ฉบับจริง " if ok else "ฉบับร่าง ") + base + ".docx" + (f"  (ยังไม่มีคะแนน {missing} เกณฑ์)" if missing else ""))
    cs = ["# สรุปผลการตรวจรายงานทั้งชั้น", f"**{title}**{{.center}}", "---",
          "| รหัสนักศึกษา | ชื่อ-สกุล | คะแนนรวม | ร้อยละ | สถานะ |", "|---|---|---|---|---|"]
    for sid, name, t, m, p, ok in summary:
        cs.append(f"| {sid} | {c(name)} | {num(t)} จาก {num(m)} | {num(p)} | {'ตรวจทานแล้ว' if ok else 'ฉบับร่าง'} |")
    if summary: cs.append(f"ค่าเฉลี่ยร้อยละ {sum(x[4] for x in summary)/len(summary):.1f} · ตรวจทานแล้ว {sum(1 for x in summary if x[5])} จาก {len(summary)} คน")
    p = os.path.join(outdir, "class-summary"); open(p + ".md", "w", encoding="utf-8").write("\n".join(cs)); convert("\n".join(cs), p + ".docx")
    print("สรุปทั้งชั้น:", p + ".docx")

if __name__ == "__main__":
    a = [x for x in sys.argv[1:] if not x.startswith("--")]
    if len(a) < 3: print(__doc__); sys.exit(1)
    main(a[0], a[1], a[2], "--no-pdf" not in sys.argv)
