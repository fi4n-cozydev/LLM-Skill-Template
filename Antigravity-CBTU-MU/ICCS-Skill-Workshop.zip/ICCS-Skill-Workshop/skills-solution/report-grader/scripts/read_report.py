#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
read_report.py — อ่านรายงานนักศึกษา (.docx) เพื่อใช้ตรวจตามเกณฑ์
ได้ไฟล์ .md ที่มี
- ข้อเท็จจริงด้านรูปแบบ: ฟอนต์และขนาดที่ใช้ ระยะขอบ หัวข้อมีเลขลำดับหรือไม่ ชื่อตาราง จำนวนหน้า การอ้างอิง
- เนื้อหาทุกย่อหน้าพร้อมชื่อหัวข้อที่ย่อหน้านั้นอยู่ และตารางแยกเป็นแถว (ใช้ระบุ "จุดในรายงาน")
วิธีใช้:  python read_report.py <รายงาน.docx> <ไฟล์ผลลัพธ์.md>
"""
import re, sys, os, json, shutil, subprocess, tempfile
from collections import Counter
from docx import Document
from docx.oxml.ns import qn

def run_font(run, para, doc):
    rpr = run._element.rPr
    name = None
    if rpr is not None and rpr.rFonts is not None:
        name = rpr.rFonts.get(qn("w:cs")) or rpr.rFonts.get(qn("w:ascii"))
    if not name:
        st = para.style
        while st is not None and not name:
            if st.font and st.font.name: name = st.font.name
            st = st.base_style
    if not name:
        name = doc.styles["Normal"].font.name or "(ค่าเริ่มต้น)"
    size = None
    if rpr is not None:
        for tag in ("w:szCs", "w:sz"):
            el = rpr.find(qn(tag))
            if el is not None: size = int(el.get(qn("w:val"))) / 2; break
    if size is None:
        st = para.style
        while st is not None and size is None:
            if st.font and st.font.size: size = st.font.size.pt
            st = st.base_style
    if size is None:
        size = doc.styles["Normal"].font.size.pt if doc.styles["Normal"].font.size else 11
    return name, size

def page_count(path):
    exe = shutil.which("soffice") or shutil.which("libreoffice")
    if not exe: return None
    d = tempfile.mkdtemp()
    subprocess.run([exe, "--headless", "--convert-to", "pdf", "--outdir", d, path], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    pdf = os.path.join(d, os.path.splitext(os.path.basename(path))[0] + ".pdf")
    if not os.path.exists(pdf): return None
    data = open(pdf, "rb").read()
    m = re.findall(rb"/Type\s*/Page[^s]", data)
    return len(m) or None

def main(src, out):
    doc = Document(src)
    lines, fonts, sizes = [], Counter(), Counter()
    section = "(ก่อนหัวข้อแรก)"; heads = []; n = 0; tcount = 0; captions = 0; chars = 0
    body = doc.element.body
    for child in body.iterchildren():
        if child.tag == qn("w:p"):
            from docx.text.paragraph import Paragraph
            p = Paragraph(child, doc)
            t = p.text.strip()
            for r in p.runs:
                if r.text.strip():
                    f, s = run_font(r, p, doc); fonts[f] += len(r.text); sizes[s] += len(r.text)
            if not t: continue
            chars += len(t)
            is_head = p.style.name.lower().startswith("heading") or (len(t) < 80 and all(r.bold for r in p.runs if r.text.strip()) and p.runs)
            if is_head:
                section = t; heads.append(t)
            if t.startswith("ตารางที่"): captions += 1
            n += 1
            lines.append(f"¶{n} [{section[:40]}] {'(หัวข้อ) ' if is_head else ''}{t}")
        elif child.tag == qn("w:tbl"):
            from docx.table import Table
            tb = Table(child, doc); tcount += 1
            lines.append(f"\n[ตาราง{tcount}] อยู่ในหัวข้อ: {section[:40]}")
            for ri, row in enumerate(tb.rows, 1):
                cells = [c.text.strip().replace("\n", " / ") for c in row.cells]
                lines.append(f"ตาราง{tcount}-แถว{ri}: " + " | ".join(cells))
                chars += sum(len(c) for c in cells)
            lines.append("")
    sec = doc.sections[0]
    cm = lambda v: round(v / 360000, 1) if v else None
    numbered = sum(1 for h in heads if re.match(r"^\d+(\.\d+)*\.?\s", h))
    body_txt = "\n".join(lines)
    cites = re.findall(r"\([^()]*\d{4}[a-z]?\)|\([^()]*\d{4}[,\s]*น\.\s*\d+[^()]*\)", body_txt)
    ref_idx = next((i for i, l in enumerate(lines) if re.search(r"บรรณานุกรม|เอกสารอ้างอิง|References", l)), None)
    refs = [l for l in lines[ref_idx + 1:] if l.startswith("¶")] if ref_idx is not None else []
    pages = page_count(src)
    fmt = [
        f"- ฟอนต์ที่ใช้ (จำนวนตัวอักษร): " + ", ".join(f"{k} {v:,}" for k, v in fonts.most_common()),
        f"- ขนาดตัวอักษร (pt): " + ", ".join(f"{k:g} pt {v:,}" for k, v in sizes.most_common()),
        f"- ระยะขอบ (ซม.): บน {cm(sec.top_margin)} ล่าง {cm(sec.bottom_margin)} ซ้าย {cm(sec.left_margin)} ขวา {cm(sec.right_margin)}",
        f"- หัวข้อที่พบ {len(heads)} หัวข้อ มีเลขลำดับ {numbered} หัวข้อ",
        f"- ตาราง {tcount} ตาราง · มีชื่อตาราง (ขึ้นต้น 'ตารางที่') {captions} รายการ",
        f"- การอ้างอิงในเนื้อหาแบบ (ผู้แต่ง, ปี) ประมาณ {len(cites)} ครั้ง · รายการบรรณานุกรม {len(refs)} รายการ",
        f"- จำนวนหน้า: {pages if pages else 'ไม่ทราบ (ไม่มี LibreOffice) — ประมาณ ' + str(round(chars/1800, 1)) + ' หน้า จากจำนวนตัวอักษร'}",
        f"- จำนวนตัวอักษรเนื้อหา: {chars:,}",
    ]
    md = f"# ข้อมูลรายงานสำหรับการตรวจ: {os.path.basename(src)}\n\n## ข้อเท็จจริงด้านรูปแบบเอกสาร\n" + "\n".join(fmt) + \
         "\n\n## หัวข้อในรายงาน\n" + "\n".join(f"- {h}" for h in heads) + "\n\n## เนื้อหาแยกตามหัวข้อ\n" + body_txt + "\n"
    os.makedirs(os.path.dirname(os.path.abspath(out)), exist_ok=True)
    open(out, "w", encoding="utf-8").write(md)
    print("อ่านรายงานแล้ว:", out, f"({n} ย่อหน้า, {tcount} ตาราง)")

if __name__ == "__main__":
    if len(sys.argv) < 3: print(__doc__); sys.exit(1)
    main(sys.argv[1], sys.argv[2])
