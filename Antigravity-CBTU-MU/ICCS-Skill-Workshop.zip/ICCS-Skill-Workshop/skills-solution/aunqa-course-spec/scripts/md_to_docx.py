#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
md_to_docx.py — แปลง Markdown เป็น Word (.docx) ที่จัดรูปแบบเรียบร้อย สำหรับเอกสารภาษาไทย
- ฟอนต์ TH SarabunPSK 16 pt ทั้งเอกสาร (ทั้งอักษรไทยและอังกฤษ)
- กระดาษ A4 ขอบ บน 2.5 / ล่าง 2 / ซ้าย 3 / ขวา 2 ซม. (ตามระเบียบงานสารบรรณ)
- ตาราง: หัวตารางพื้นสีน้ำเงินเข้ม ตัวหนาสีขาว เส้นตารางบาง แถวสลับสี ทำซ้ำหัวตารางเมื่อขึ้นหน้าใหม่
- ใช้ไฟล์ .docx เดิมเป็นแม่แบบได้ (--template) เพื่อคงหัวกระดาษ โลโก้ และท้ายกระดาษ

วิธีใช้
  python md_to_docx.py input.md output.docx
  python md_to_docx.py input.md output.docx --template แม่แบบ.docx --replace "........=นางสาวพิมพ์ชนก" --pdf

รูปแบบ Markdown ที่รองรับ
  # หัวเรื่องเอกสาร (กึ่งกลาง ตัวหนา 18 pt)      ## หัวข้อ (ตัวหนา)      ### หัวข้อย่อย (ตัวหนา)
  **ตัวหนา**  *ตัวเอียง*   - รายการ   1. รายการลำดับเลข   | ตาราง |   > กล่องหมายเหตุ   --- เส้นคั่น
  ทุกบรรทัดที่ไม่ว่างคือ 1 ย่อหน้า (ภาษาไทยไม่ต้องเว้นบรรทัดระหว่างย่อหน้า)
  ท้ายบรรทัดใส่ {.center} {.right} {.indent} {.sign} {.noindent} เพื่อจัดตำแหน่ง
  บรรทัด ---pagebreak--- = ขึ้นหน้าใหม่      อักขระ Tab ใช้จัดป้ายหัวข้อ เช่น "ที่\tอว 78.108/...."
"""
import argparse, copy, re, subprocess, sys, os, shutil
from docx import Document
from docx.shared import Pt, Cm, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.section import WD_ORIENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

FONT = "TH SarabunPSK"
SIZE = 16
HEAD_FILL = "1F3A6E"
ZEBRA = "EEF3FA"
BORDER = "9AA8BD"

# ---------------------------------------------------------------- fonts
def set_run_font(run, size=SIZE, bold=None, italic=None, color=None):
    run.font.name = FONT
    run.font.size = Pt(size)
    rpr = run._element.get_or_add_rPr()
    rfonts = rpr.find(qn("w:rFonts"))
    if rfonts is None:
        rfonts = OxmlElement("w:rFonts"); rpr.insert(0, rfonts)
    for a in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
        rfonts.set(qn(a), FONT)
    for tag in ("w:szCs",):
        el = rpr.find(qn(tag))
        if el is None:
            el = OxmlElement(tag); rpr.append(el)
        el.set(qn("w:val"), str(int(size * 2)))
    if bold is not None:
        run.bold = bold
        b = rpr.find(qn("w:bCs"))
        if bold and b is None:
            rpr.append(OxmlElement("w:bCs"))
    if italic is not None:
        run.italic = italic
    if color:
        run.font.color.rgb = RGBColor.from_string(color)

def setup_styles(doc):
    for name in ("Normal", "Table Grid") if "Table Grid" in [s.name for s in doc.styles] else ("Normal",):
        st = doc.styles[name]
        st.font.name = FONT; st.font.size = Pt(SIZE)
        rpr = st.element.get_or_add_rPr()
        rf = rpr.find(qn("w:rFonts"))
        if rf is None:
            rf = OxmlElement("w:rFonts"); rpr.insert(0, rf)
        for a in ("w:ascii", "w:hAnsi", "w:cs", "w:eastAsia"):
            rf.set(qn(a), FONT)
        szcs = rpr.find(qn("w:szCs"))
        if szcs is None:
            szcs = OxmlElement("w:szCs"); rpr.append(szcs)
        szcs.set(qn("w:val"), str(SIZE * 2))
        lang = rpr.find(qn("w:lang"))
        if lang is None:
            lang = OxmlElement("w:lang"); rpr.append(lang)
        lang.set(qn("w:bidi"), "th-TH")
    pf = doc.styles["Normal"].paragraph_format
    pf.space_before = Pt(0); pf.space_after = Pt(0); pf.line_spacing = 1.0

# ---------------------------------------------------------------- inline
INLINE = re.compile(r"(\*\*[^*]+\*\*|\*[^*]+\*)")
def add_inline(par, text, size=SIZE, bold=False, color=None):
    parts = re.split(r"<br\s*/?>", text)
    for i, part in enumerate(parts):
        if i:
            par.add_run().add_break()
        for tok in INLINE.split(part):
            if not tok:
                continue
            if tok.startswith("**") and tok.endswith("**"):
                r = par.add_run(tok[2:-2]); set_run_font(r, size, True, color=color)
            elif tok.startswith("*") and tok.endswith("*") and len(tok) > 2:
                r = par.add_run(tok[1:-1]); set_run_font(r, size, bold, True, color=color)
            else:
                r = par.add_run(tok); set_run_font(r, size, bold, color=color)

def shade(el_pr, fill):
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear"); shd.set(qn("w:color"), "auto"); shd.set(qn("w:fill"), fill)
    el_pr.append(shd)

def para_border_bottom(par, color="7F8FA9", sz=6):
    ppr = par._p.get_or_add_pPr()
    pbdr = OxmlElement("w:pBdr"); b = OxmlElement("w:bottom")
    b.set(qn("w:val"), "single"); b.set(qn("w:sz"), str(sz)); b.set(qn("w:space"), "1"); b.set(qn("w:color"), color)
    pbdr.append(b); ppr.append(pbdr)

def add_tabs(par, n=12, step=1.25, first=None):
    ts = par.paragraph_format.tab_stops
    if first:
        ts.add_tab_stop(Cm(first))
    for i in range(1, n + 1):
        if not first or step * i > first:
            ts.add_tab_stop(Cm(step * i))

# ---------------------------------------------------------------- table
def set_cell_margins(tbl, top=60, bottom=60, left=100, right=100):
    tblpr = tbl._tbl.tblPr
    mar = OxmlElement("w:tblCellMar")
    for k, v in (("top", top), ("left", left), ("bottom", bottom), ("right", right)):
        e = OxmlElement(f"w:{k}"); e.set(qn("w:w"), str(v)); e.set(qn("w:type"), "dxa"); mar.append(e)
    tblpr.append(mar)

def set_borders(tbl):
    tblpr = tbl._tbl.tblPr
    b = OxmlElement("w:tblBorders")
    for edge in ("top", "left", "bottom", "right", "insideH", "insideV"):
        e = OxmlElement(f"w:{edge}"); e.set(qn("w:val"), "single"); e.set(qn("w:sz"), "4")
        e.set(qn("w:space"), "0"); e.set(qn("w:color"), BORDER); b.append(e)
    tblpr.append(b)

NUMERIC = re.compile(r"^[\s\d,.%+\-–/()฿]+$")
def build_table(doc, rows, width_cm):
    header, body = rows[0], rows[1:]
    ncol = len(header)
    body = [r + [""] * (ncol - len(r)) for r in body]
    tbl = doc.add_table(rows=1 + len(body), cols=ncol)
    tbl.alignment = WD_TABLE_ALIGNMENT.CENTER
    tbl.autofit = False
    set_borders(tbl); set_cell_margins(tbl, top=20, bottom=20)
    # column widths: short columns fit on one line, long columns share the rest
    def vis(t):
        t = re.sub(r"\*|<br\s*/?>", "", t)
        return len(re.sub(r"[\u0E31\u0E34-\u0E3A\u0E47-\u0E4E]", "", t))
    need = []
    for c in range(ncol):
        m = max([vis(r[c]) for r in body] + [max(vis(w) for w in (header[c].split() or ['']))])
        need.append(min(m, 70) * 0.32 + 0.6)
    # water-filling: columns that fit within a fair share get what they need,
    # the remaining wide columns share the rest in proportion to sqrt(need)
    cms = [0.0] * ncol; left = list(range(ncol)); room = width_cm
    wt = [n ** 0.5 for n in need]  # ส่วนแบ่งตามรากที่สองของความยาวข้อความ
    while left:
        tot = sum(wt[k] for k in left)
        fit = [k for k in left if need[k] <= room * wt[k] / tot]
        if not fit:
            for k in left:
                cms[k] = room * wt[k] / tot
            break
        for k in fit:
            cms[k] = need[k]; room -= need[k]; left.remove(k)
    if not left and room > 0.01:
        tot = sum(cms)
        cms = [x + room * x / tot for x in cms]
    # ทุกคอลัมน์กว้างอย่างน้อย min(ที่ต้องการ, 3.2 ซม.) โดยยืมจากคอลัมน์ที่กว้างที่สุด
    for k in range(ncol):
        want = min(need[k], 3.2)
        if cms[k] < want:
            j = max(range(ncol), key=lambda i: cms[i]); d = want - cms[k]
            if cms[j] - d > want: cms[j] -= d; cms[k] = want
    widths = [Cm(x) for x in cms]
    for ri, row in enumerate([header] + body):
        tr = tbl.rows[ri]
        if ri == 0:
            trpr = tr._tr.get_or_add_trPr(); h = OxmlElement("w:tblHeader"); h.set(qn("w:val"), "true"); trpr.append(h)
        cant = OxmlElement("w:cantSplit"); tr._tr.get_or_add_trPr().append(cant)
        for ci in range(ncol):
            cell = tr.cells[ci]; cell.width = widths[ci]
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER
            txt = row[ci].strip() if ci < len(row) else ""
            p = cell.paragraphs[0]
            if ri == 0:
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                add_inline(p, txt.replace("**", ""), bold=True, color="FFFFFF")
                shade(cell._tc.get_or_add_tcPr(), HEAD_FILL)
            else:
                if NUMERIC.match(txt) and txt:
                    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                add_inline(p, txt)
                if ri % 2 == 0:
                    shade(cell._tc.get_or_add_tcPr(), ZEBRA)
                if txt.startswith("**") and ("รวม" in txt or "Total" in txt):
                    for c2 in tr.cells:
                        shade(c2._tc.get_or_add_tcPr(), "D9E2F1")
    for ci, w in enumerate(widths):
        tbl.columns[ci].width = w
    grid = tbl._tbl.tblGrid  # LibreOffice/Word ใช้ gridCol เป็นหลัก
    for ci, gc in enumerate(grid.findall(qn("w:gridCol"))):
        gc.set(qn("w:w"), str(int(widths[ci].twips if hasattr(widths[ci], "twips") else widths[ci] / 635)))
    tw = OxmlElement("w:tblW"); tw.set(qn("w:w"), str(int(sum(cms) * 567))); tw.set(qn("w:type"), "dxa")
    old = tbl._tbl.tblPr.find(qn("w:tblW"))
    if old is not None: tbl._tbl.tblPr.remove(old)
    tbl._tbl.tblPr.append(tw)
    sp = doc.add_paragraph(); sp.paragraph_format.space_after = Pt(0)
    r = sp.add_run(" "); set_run_font(r, 8)  # small gap after table
    return tbl

# ---------------------------------------------------------------- template
def clear_body_keep_section(doc):
    body = doc.element.body
    for child in list(body):
        if child.tag == qn("w:sectPr"):
            continue
        body.remove(child)

def replace_in_part(element, pairs):
    """แทนข้อความใน header/footer/text box — แทนใน run เดียวก่อน ถ้าข้อความถูกแยกหลาย run จึงรวมทั้งย่อหน้า"""
    for p in element.iter(qn("w:p")):
        ts = list(p.iter(qn("w:t")))
        if not ts:
            continue
        for a, b in pairs:
            hit = False
            for t in ts:
                if t.text and a in t.text:
                    t.text = t.text.replace(a, b); hit = True
            if hit:
                continue
            joined = "".join(t.text or "" for t in ts)
            if a in joined:
                ts[0].text = joined.replace(a, b)
                ts[0].set("{http://www.w3.org/XML/1998/namespace}space", "preserve")
                for t in ts[1:]:
                    t.text = ""

# ---------------------------------------------------------------- main
DIRECTIVE = re.compile(r"\s*\{\.(center|right|indent|sign|noindent)\}\s*$")
def convert(md_text, out, template=None, replace=None, landscape=False, page_numbers=True, bottom_margin=None):
    if template:
        doc = Document(template); clear_body_keep_section(doc)
        if replace:
            for s in doc.sections:
                for part in (s.header, s.footer, s.first_page_header, s.first_page_footer, s.even_page_header, s.even_page_footer):
                    try:
                        replace_in_part(part._element, replace)
                    except Exception:
                        pass
    else:
        doc = Document()
        sec = doc.sections[0]
        if landscape:
            sec.orientation = WD_ORIENT.LANDSCAPE
            sec.page_width, sec.page_height = Cm(29.7), Cm(21.0)
        else:
            sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
        sec.top_margin, sec.bottom_margin, sec.left_margin, sec.right_margin = (Cm(2.0), Cm(1.8), Cm(2.0), Cm(2.0)) if landscape else (Cm(2.5), Cm(2.0), Cm(3.0), Cm(2.0))
        if page_numbers:
            fp = sec.footer.paragraphs[0]; fp.alignment = WD_ALIGN_PARAGRAPH.CENTER
            r = fp.add_run(); set_run_font(r, 14)
            for kind, txt in (("begin", None), (None, "PAGE"), ("end", None)):
                if kind:
                    fc = OxmlElement("w:fldChar"); fc.set(qn("w:fldCharType"), kind); r._element.append(fc)
                else:
                    it = OxmlElement("w:instrText"); it.set(qn("xml:space"), "preserve"); it.text = txt; r._element.append(it)
    setup_styles(doc)
    sec = doc.sections[-1]
    if bottom_margin:
        sec.bottom_margin = Cm(bottom_margin)
    width_cm = (sec.page_width - sec.left_margin - sec.right_margin) / 360000

    lines = md_text.splitlines()
    last_label_indent = [0]
    i = 0
    while i < len(lines):
        raw = lines[i].rstrip("\n")
        line = raw.strip().replace("\\t", "\t")
        if line.startswith("<!--"):
            i += 1; continue
        if not line:
            if raw.startswith(" "):  # บรรทัดที่มีแต่ช่องว่าง = เว้นบรรทัด 1 บรรทัด
                ep = doc.add_paragraph(); ep.paragraph_format.keep_with_next = True
            i += 1; continue
        if line == "---pagebreak---":
            doc.add_paragraph().add_run().add_break(WD_BREAK.PAGE); i += 1; continue
        if re.fullmatch(r"-{3,}|_{3,}", line):
            p = doc.add_paragraph(); para_border_bottom(p); i += 1; continue
        if line.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].strip().startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                    rows.append(cells)
                i += 1
            if rows:
                build_table(doc, rows, width_cm)
            continue
        m = DIRECTIVE.search(line); d = m.group(1) if m else None
        if m:
            line = line[:m.start()]
        if line.startswith("# "):
            p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.space_after = Pt(6)
            add_inline(p, line[2:].strip(), size=18, bold=True)
        elif line.startswith("## "):
            p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(10); p.paragraph_format.space_after = Pt(2)
            p.paragraph_format.keep_with_next = True
            add_inline(p, line[3:].strip(), size=SIZE + 1, bold=True, color="1F3A6E")
        elif line.startswith("### ") or line.startswith("#### "):
            p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(6); p.paragraph_format.keep_with_next = True
            add_inline(p, line.split(" ", 1)[1].strip(), bold=True)
        elif line.startswith("> "):
            p = doc.add_paragraph(); p.paragraph_format.left_indent = Cm(0.4)
            shade(p._p.get_or_add_pPr(), "F1F4F9")
            add_inline(p, line[2:])
        elif (re.match(r"^[-*•] ", line) or re.match(r"^\d+[.)] ", line)) and d != "indent":
            indent_level = (len(raw) - len(raw.lstrip(" "))) // 2
            bullet = re.match(r"^([-*•]|\d+[.)]) ", line)
            mark = "•" if bullet.group(1) in "-*•" else bullet.group(1)
            p = doc.add_paragraph()
            pf = p.paragraph_format
            pf.left_indent = Cm(1.25 + 0.75 * indent_level + (0.0 if d != "indent" else 1.25)); pf.first_line_indent = Cm(-0.65)
            add_inline(p, mark + "\t" + line[bullet.end():])
            pf.tab_stops.add_tab_stop(pf.left_indent)
        else:
            p = doc.add_paragraph()
            lab = re.match(r"^\*\*([^*]+)\*\*\t", line)
            if lab:
                w = len(re.sub(r"[\u0E31\u0E34-\u0E3A\u0E47-\u0E4E]", "", lab.group(1))) * 0.36 + 0.4
                stop = 2.5 if w <= 2.3 else 1.25 * (int(w / 1.25) + 1)
                p.paragraph_format.left_indent = Cm(stop); p.paragraph_format.first_line_indent = Cm(-stop)
                last_label_indent[0] = stop
            elif line.startswith("\t") and last_label_indent[0]:
                line = line.lstrip("\t"); p.paragraph_format.left_indent = Cm(last_label_indent[0])
            else:
                last_label_indent[0] = 0
            if re.fullmatch(r"\*\*[^*]+\*\*", line):
                p.paragraph_format.keep_with_next = True; p.paragraph_format.space_before = Pt(4)
            if "\t" in line:
                add_tabs(p, first=last_label_indent[0] or None)
            if d == "center":
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER
            elif d == "right":
                p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            elif d == "sign":
                p.alignment = WD_ALIGN_PARAGRAPH.CENTER; p.paragraph_format.left_indent = Cm(7.0)
                p.paragraph_format.keep_with_next = True
            elif d == "indent":
                p.paragraph_format.first_line_indent = Cm(2.5); p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
                p.paragraph_format.space_before = Pt(4)
            nxt = next((l.strip() for l in lines[i + 1:] if l.strip()), "")
            mn = DIRECTIVE.search(nxt)
            if d != "sign" and mn and mn.group(1) == "sign":
                p.paragraph_format.keep_with_next = True  # ย่อหน้าสุดท้ายอยู่หน้าเดียวกับส่วนลงนาม
            add_inline(p, line)
        i += 1
    doc.save(out)
    return out

def to_pdf(docx_path):
    exe = shutil.which("soffice") or shutil.which("libreoffice")
    if not exe:
        print("ไม่พบ LibreOffice — ข้ามการสร้าง PDF (เปิดไฟล์ใน Word แล้ว Save as PDF แทน)"); return None
    outdir = os.path.dirname(os.path.abspath(docx_path))
    subprocess.run([exe, "--headless", "--convert-to", "pdf", "--outdir", outdir, docx_path], check=False,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    return os.path.splitext(docx_path)[0] + ".pdf"

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("markdown"); ap.add_argument("output")
    ap.add_argument("--template", help="ไฟล์ .docx ที่ใช้เป็นแม่แบบ (คงหัวกระดาษ/ท้ายกระดาษ/โลโก้)")
    ap.add_argument("--replace", action="append", default=[], help='แทนข้อความในหัว/ท้ายกระดาษ รูปแบบ "เดิม=ใหม่" ใช้ซ้ำได้')
    ap.add_argument("--landscape", action="store_true"); ap.add_argument("--no-page-number", action="store_true")
    ap.add_argument("--pdf", action="store_true", help="สร้าง PDF ด้วย LibreOffice ถ้ามี")
    ap.add_argument("--bottom-margin", type=float, help="ขอบล่าง (ซม.) เช่น 3.5 เมื่อแม่แบบมีกรอบท้ายกระดาษ")
    a = ap.parse_args()
    pairs = [tuple(x.split("=", 1)) for x in a.replace if "=" in x]
    with open(a.markdown, encoding="utf-8") as f:
        convert(f.read(), a.output, a.template, pairs, a.landscape, not a.no_page_number, a.bottom_margin)
    print("สร้างไฟล์แล้ว:", a.output)
    if a.pdf:
        print("PDF:", to_pdf(a.output))
