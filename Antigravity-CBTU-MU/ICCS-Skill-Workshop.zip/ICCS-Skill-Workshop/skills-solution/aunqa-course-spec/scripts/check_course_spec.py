#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""check_course_spec.py — ตรวจความสอดคล้องของรายละเอียดรายวิชา (Markdown) ก่อนส่ง
ตรวจ: (1) น้ำหนักการประเมินรวม 100 (2) ทุก CLO มี PLO รองรับ มีกิจกรรมสอน และถูกประเมิน
      (3) ชั่วโมงรวมในแผนการสอนตรงกับหน่วยกิต (4) มีหัวข้อครบ 11 หัวข้อ
วิธีใช้: python check_course_spec.py output/course-spec-MGT305.md
"""
import re, sys
md = open(sys.argv[1], encoding="utf-8").read()
def tables_after(head):
    i = md.find(head)
    if i < 0: return []
    seg = md[i:]; seg = seg[seg.find("\n"):]
    nxt = re.search(r"\n## ", seg); seg = seg[: nxt.start()] if nxt else seg
    rows = [[c.strip() for c in l.strip().strip("|").split("|")] for l in seg.splitlines() if l.strip().startswith("|")]
    return [r for r in rows if not all(re.fullmatch(r":?-{2,}:?", c) for c in r)]
ok = True
def report(flag, msg):
    global ok; ok &= flag; print(("ผ่าน  " if flag else "ไม่ผ่าน ") + msg)
heads = ["## 1.", "## 2.", "## 3.", "## 4.", "## 5.", "## 6.", "## 7.", "## 8.", "## 9.", "## 10.", "## 11."]
report(all(h in md for h in heads), "มีหัวข้อครบ 11 หัวข้อ")
clos = sorted(set(re.findall(r"CLO\d+", "".join("|".join(r) for r in tables_after("## 4."))[0:])), key=lambda x: int(x[3:]))
report(len(clos) >= 3, f"พบ CLO {len(clos)} ข้อ: {', '.join(clos)}")
amap = tables_after("## 5.")
for c in clos:
    row = next((r for r in amap if r and r[0] == c), None)
    report(bool(row) and any("✓" in x for x in row[1:]), f"{c} มี PLO รองรับในตาราง Constructive Alignment")
tl = "\n".join("|".join(r) for r in tables_after("## 6."))
ass = tables_after("## 8.")
ass_txt = "\n".join("|".join(r) for r in ass)
def expand(s):
    out = set()
    for a, b in re.findall(r"CLO(\d+)\s*[–-]\s*CLO(\d+)", s): out |= {f"CLO{k}" for k in range(int(a), int(b) + 1)}
    return out | set(re.findall(r"CLO\d+", s))
for c in clos:
    report(c in expand(tl), f"{c} มีกิจกรรมการเรียนการสอน (หัวข้อ 6)")
    report(c in expand(ass_txt), f"{c} ถูกประเมินในแผนการประเมิน (หัวข้อ 8)")
w = 0
for r in ass[1:]:
    if r and "รวม" in r[0]: continue
    m = re.search(r"(\d+(?:\.\d+)?)", r[-1]) if r else None
    if m: w += float(m.group(1))
report(abs(w - 100) < 0.01, f"น้ำหนักการประเมินรวม = {w:g} (ต้องเท่ากับ 100)")
cr = re.search(r"(\d)\((\d+)-(\d+)-(\d+)\)", md)
plan = tables_after("## 7.")
hrs = 0
for r in plan[1:]:
    if r and "รวม" in r[0]: continue
    m = re.search(r"(\d+)", r[-1]) if r else None
    if m: hrs += int(m.group(1))
if cr:
    need = (int(cr.group(2)) + int(cr.group(3))) * 15
    report(hrs == need, f"ชั่วโมงในแผนการสอน = {hrs} (หน่วยกิต {cr.group(0)} ต้องการ {need})")
print("\nสรุป:", "ผ่านทุกข้อ" if ok else "มีข้อที่ต้องแก้ — แก้ใน .md แล้วรันใหม่")
sys.exit(0 if ok else 1)
