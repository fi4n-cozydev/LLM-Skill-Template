---
marp: true
theme: mahidol
size: 16:9
paginate: true
title: 'ระบบจองห้องประชุมออนไลน์'
author: 'สมศรี'
footer: 'ระบบจองห้องประชุม | ฝ่ายบริหารทั่วไป'
---

<style>
section:not(.lead) .visual-grid { margin-top:24px; }
section:not(.lead) .visual-card { min-height:250px; padding:26px; }
section:not(.lead) .visual-card h3 { font-size:30px; }
section:not(.lead) .visual-card p, .visual-card li { font-size:24px; line-height:1.6; }
.visual-card ul { margin:10px 0 0; padding-left:26px; }
.visual-card li { margin-bottom:6px; }
.big { display:grid; grid-template-columns:420px 1fr; align-items:center; gap:48px; margin:28px 0 24px; }
.big .value { font-size:170px; font-weight:700; color:#0891b2; line-height:1.05; }
.big .unit { font-size:28px; font-weight:600; color:#1e3a8a; line-height:1.5; margin-top:8px; }
.big .desc { font-size:30px; line-height:1.6; color:#1f2937; border-left:5px solid #2563eb; padding-left:28px; }
section ol li { font-size:30px; margin-bottom:14px; }
.action { margin-top:30px; background:#0e7490; color:#ffffff; border-radius:14px; padding:20px 28px; font-size:28px; font-weight:600; }
</style>

<!-- _class: lead -->
<!-- _paginate: false -->

<img class="university-logo" src="fig/logos/mahidol.svg" alt="ตราหน่วยงาน">

# ระบบจองห้องประชุมออนไลน์

<div class="subtitle">จองห้องประชุมได้เองภายในไม่กี่นาที และเห็นตารางการใช้ห้องร่วมกัน</div>

**สมศรี**
ฝ่ายบริหารทั่วไป · [วันที่]

---

## สิ่งที่เปลี่ยนแปลง

<div class="visual-grid">
<div class="visual-card"><h3>จองได้ทุกที่</h3><p>จองผ่านเว็บไซต์ของหน่วยงาน ไม่ต้องกรอกแบบฟอร์มกระดาษ</p></div>
<div class="visual-card"><h3>เห็นตารางร่วมกัน</h3><p>ตรวจสอบห้องว่างได้ทันที ลดการจองซ้อน</p></div>
<div class="visual-card ai"><h3>อนุมัติอัตโนมัติ</h3><p>ห้องประชุมเล็กอนุมัติทันที ห้องใหญ่ส่งหัวหน้าฝ่ายพิจารณา</p></div>
</div>

---

## ขั้นตอนการจองที่สั้นลง

<div class="big">
<div><div class="value">3</div><div class="unit">ขั้นตอน: เลือกห้อง · เลือกเวลา · ยืนยัน</div></div>
<div class="desc">จากเดิมต้องกรอกแบบฟอร์ม โทรสอบถามห้องว่าง และรอการอนุมัติทางอีเมล</div>
</div>

<div class="diagram-caption">ที่มา: คู่มือการใช้งานระบบจองห้องประชุม (ตัวอย่างสมมติ)</div>

---

## การจองแบบเดิมกับระบบใหม่

<div class="visual-grid two">
<div class="visual-card"><h3>แบบเดิม</h3><ul><li>กรอกแบบฟอร์มกระดาษ</li><li>โทรสอบถามห้องว่าง</li><li>รอการอนุมัติทางอีเมล</li></ul></div>
<div class="visual-card ai"><h3>ระบบใหม่</h3><ul><li>จองผ่านเว็บไซต์</li><li>เห็นห้องว่างทันที</li><li>แจ้งผลอัตโนมัติ</li></ul></div>
</div>

---

## สรุป

1. ทุกคนจองห้องประชุมได้ด้วยตนเอง
2. ตารางการใช้ห้องเป็นปัจจุบันเสมอ
3. ลดการจองซ้อนและการติดตามทางโทรศัพท์

<div class="action">เริ่มใช้ระบบใหม่สำหรับการจองตั้งแต่เดือนหน้า</div>
