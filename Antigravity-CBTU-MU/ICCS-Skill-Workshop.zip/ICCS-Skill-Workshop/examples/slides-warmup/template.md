---
marp: true
theme: mahidol
size: 16:9
paginate: true
title: '{{ชื่อเรื่อง}}'
author: '{{ผู้นำเสนอ}}'
footer: '{{ชื่อเรื่องย่อ}} | {{หน่วยงาน}}'
---

<style>
section:not(.lead) .visual-grid { margin-top:24px; }
section:not(.lead) .visual-card { min-height:250px; padding:26px; }
section:not(.lead) .visual-card h3 { font-size:30px; }
section:not(.lead) .visual-card p, .visual-card li { font-size:24px; line-height:1.6; }
.visual-card ul { margin:10px 0 0; padding-left:26px; }
.visual-card li { margin-bottom:6px; }
.big { display:grid; grid-template-columns:420px 1fr; align-items:center; gap:48px; margin:28px 0 24px; }
.big .value { font-size:170px; font-weight:700; color:#0891b2; line-height:1.05; }
.big .unit { font-size:28px; font-weight:600; color:#1e3a8a; line-height:1.5; margin-top:8px; }
.big .desc { font-size:30px; line-height:1.6; color:#1f2937; border-left:5px solid #2563eb; padding-left:28px; }
section ol li { font-size:30px; margin-bottom:14px; }
.action { margin-top:30px; background:#0e7490; color:#ffffff; border-radius:14px; padding:20px 28px; font-size:28px; font-weight:600; }
</style>

<!-- _class: lead -->
<!-- _paginate: false -->

<img class="university-logo" src="fig/logos/mahidol.svg" alt="ตราหน่วยงาน">

# {{ชื่อเรื่อง ไม่เกิน 2 บรรทัด}}

<div class="subtitle">{{ประโยคเดียวที่บอกว่าผู้ฟังจะได้อะไร}}</div>

**{{ผู้นำเสนอ}}**
{{หน่วยงาน}} · {{วันที่}}

---

## {{หัวข้อ: ประเด็นหลัก 3 ข้อ}}

<div class="visual-grid">
<div class="visual-card"><h3>{{ประเด็น 1}}</h3><p>{{คำอธิบายไม่เกิน 2 บรรทัด}}</p></div>
<div class="visual-card"><h3>{{ประเด็น 2}}</h3><p>{{คำอธิบายไม่เกิน 2 บรรทัด}}</p></div>
<div class="visual-card ai"><h3>{{ประเด็น 3}}</h3><p>{{คำอธิบายไม่เกิน 2 บรรทัด}}</p></div>
</div>

---

## {{หัวข้อ: ตัวเลขหรือข้อความเด่น}}

<div class="big">
<div><div class="value">{{ตัวเลขเด่น}}</div><div class="unit">{{หน่วย/ความหมายของตัวเลข}}</div></div>
<div class="desc">{{คำอธิบาย 2–3 บรรทัด}}</div>
</div>

<div class="diagram-caption">ที่มา: {{แหล่งที่มาของตัวเลข}}</div>

---

## {{หัวข้อการเปรียบเทียบ}}

<div class="visual-grid two">
<div class="visual-card"><h3>{{ฝั่งซ้าย เช่น แบบเดิม}}</h3><ul><li>{{ข้อ 1}}</li><li>{{ข้อ 2}}</li><li>{{ข้อ 3}}</li></ul></div>
<div class="visual-card ai"><h3>{{ฝั่งขวา เช่น แบบใหม่}}</h3><ul><li>{{ข้อ 1}}</li><li>{{ข้อ 2}}</li><li>{{ข้อ 3}}</li></ul></div>
</div>

---

## สรุป

1. {{ข้อสรุป 1}}
2. {{ข้อสรุป 2}}
3. {{ข้อสรุป 3}}

<div class="action">{{สิ่งที่ขอให้ผู้ฟังดำเนินการ 1 ประโยค}}</div>
