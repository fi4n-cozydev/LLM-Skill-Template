# แม่แบบสไลด์ 5 หน้า (ธีม Mahidol สำหรับ Marp)
| ไฟล์ | คืออะไร |
|---|---|
| template.md | แม่แบบ 5 หน้า: ปก · ประเด็นหลัก 3 ข้อ · ตัวเลขเด่น · เปรียบเทียบ · สรุป (ช่อง {{...}} สำหรับเติมเนื้อหา) |
| themes/theme-mahidol.css | ธีมสีน้ำเงิน ฟอนต์ Noto Sans Thai / Sarabun |
| fig/logos/mahidol.svg | ตราบนหน้าปก (เปลี่ยนเป็นตราหน่วยงานของท่านได้) |
| example-slides.pdf | ตัวอย่างผลลัพธ์ (ข้อมูลสมมติ) |

แม่แบบดัดแปลงจาก Skill mahidol-marp-slides (github.com/toche7/mySkills)
