# ชุดไฟล์ Workshop การสร้างและใช้งาน Skill ด้วย Google Antigravity
หลักสูตร การใช้งาน AI Agent สำหรับการทำงาน

## การเริ่มต้น
1. แตกไฟล์ zip ไว้ที่ Desktop จะได้โฟลเดอร์ `ICCS-Skill-Workshop`
2. เปิด Antigravity Desktop → **New Project** → เลือกโฟลเดอร์ `ICCS-Skill-Workshop`
3. ทำตามลำดับใน `prompts/` หรือหน้าเว็บ Workshop โดยคัดลอกคำสั่งไปวางในหน้าต่างแชต

## การสั่งงานใน Antigravity
- `@` อ้างถึงไฟล์หรือโฟลเดอร์
- `/` เรียกใช้ Skill ใน Workspace (เปิดแชตใหม่หลังสร้าง Skill)
- คำสั่งอื่นพิมพ์เป็นภาษาไทยได้ตามปกติ

## โครงสร้างโฟลเดอร์
```
ICCS-Skill-Workshop/
├── examples/          ไฟล์ต้นแบบ (งานที่เคยทำ) ใช้กำหนดรูปแบบ
│   ├── slides-warmup/   แม่แบบสไลด์ 5 หน้า (Marp ธีม Mahidol)
│   ├── minutes/         รายงานการประชุม 1/2569
│   ├── meeting/         หนังสือเชิญและกำหนดการ (แม่แบบ TPQI 2569)
│   ├── aunqa/           รายละเอียดรายวิชาตามเกณฑ์ AUN-QA v4.0
│   ├── project-results/ One Page และ Dashboard ผลการดำเนินโครงการปี 2568
│   ├── grading/         รายงานผลการตรวจรายบุคคล (ตัวอย่างรูปแบบ)
│   └── my-work/         ไฟล์งานของท่าน (การบ้าน)
├── input/             ข้อมูลงานใหม่ (ข้อมูลสมมติทั้งหมด)
│   ├── grading/         เกณฑ์การให้คะแนน โจทย์ และแบบบันทึกคะแนน
│   └── student-reports/ รายงานนักศึกษา 5 ฉบับ
├── output/            ผลงานที่ AI จัดทำ
├── prompts/           คำสั่งทุกขั้นตอน
├── tools/             เครื่องมือจัดรูปแบบไฟล์ (AI เป็นผู้ใช้งาน)
├── skills-template/   แม่แบบ SKILL.md
└── skills-solution/   Skill ฉบับสมบูรณ์ (ทางเลือกสำรอง)
```
Skill ที่สร้างจะอยู่ที่ `.agents/skills/<ชื่อ-skill>/SKILL.md` (Workspace Skill)

## Workshop
| ลำดับ | งาน | โมเดล | Skill |
|---|---|---|---|
| เริ่มต้น | ทำสไลด์ 5 หน้าด้วย /grill-me แล้วบันทึกเป็น Skill แรก (PDF ตามแม่แบบ Mahidol) | Gemini | quick-slides |
| 1 | รายงานการประชุม | Gemini | meeting-minutes |
| 2 | หนังสือเชิญประชุมและกำหนดการ | Gemini | meeting-invite-docs |
| 3 | รายละเอียดรายวิชาตามเกณฑ์ AUN-QA | Claude | aunqa-course-spec |
| 4 | One Page และ Dashboard ผลการดำเนินโครงการ | GPT-OSS | project-dashboard |
| 5 | ตรวจรายงานนักศึกษา (อาจารย์ตรวจทาน) | Claude | report-grader |

## ข้อกำหนดของเครื่อง
- Python พร้อมไลบรารี `python-docx` และ `openpyxl` (AI ติดตั้งให้ได้ด้วยคำสั่ง `pip install python-docx openpyxl`)
- ฟอนต์ TH SarabunPSK (เครื่องในหน่วยงานราชการส่วนใหญ่มีอยู่แล้ว)
- Node.js และ Chrome หรือ Edge สำหรับแปลงสไลด์เป็น PDF ด้วย Marp (Skill แรก) — หรือใช้ส่วนขยาย Marp for VS Code
- ฟอนต์ Noto Sans Thai หรือ Sarabun สำหรับสไลด์ (ธีมโหลดจาก Google Fonts ให้เมื่อออนไลน์)

> ข้อมูลใน `input/` เป็นข้อมูลสมมติสำหรับการฝึก หากใช้เอกสารจริง ให้เลือกเฉพาะเอกสารที่ไม่เป็นความลับและไม่มีข้อมูลส่วนบุคคล
