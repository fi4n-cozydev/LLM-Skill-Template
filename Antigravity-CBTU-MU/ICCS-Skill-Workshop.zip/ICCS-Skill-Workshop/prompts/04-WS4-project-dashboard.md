# Workshop 4: One Page และ Dashboard ผลการดำเนินโครงการ
โมเดล: **GPT-OSS** · เวลา 30 นาที · Skill: project-dashboard
ไฟล์ต้นแบบ: `examples/project-results/` · ข้อมูลใหม่: `input/project-report.md` และ `input/training-data.xlsx`
> โครงการตัวอย่าง: โครงการยกระดับทักษะดิจิทัลผู้ประกอบการชุมชน ปีงบประมาณ 2569 ศูนย์การเรียนรู้เมืองใหม่ — อบรม 4 รุ่น 120 คน งบประมาณ 300,000 บาท ติดตามผล 3 เดือน (ข้อมูลสมมติ)

## ขั้นที่ 1 ศึกษาไฟล์ต้นแบบ
- `examples/project-results/example-onepage-2568.pdf` — One Page A4 ของโครงการปี 2568 สำหรับแนบหนังสือรายงาน
- `examples/project-results/example-dashboard-2568.html` — Dashboard เปิดด้วยเบราว์เซอร์ ชี้เมาส์ที่กราฟและกด “ดูข้อมูล”
- `examples/project-results/design-rules.md` — แนวทางเนื้อหาและรูปแบบของหน่วยงาน
- `input/training-data.xlsx` — ข้อมูลปี 2569 จำนวน 4 ชีต: รายรุ่น รายตำบล งบประมาณ และติดตามผล

## ขั้นที่ 2 สร้าง Skill
```
อ่านตัวอย่างงานปี 2568 และแนวทางใน @examples/project-results และวิธีใช้เครื่องมือ @tools/xlsx_summary.py @tools/build_onepage.py @tools/build_dashboard.py
แล้วสร้าง Workspace Skill ชื่อ project-dashboard ตามโครงสร้าง @skills-template/SKILL-template.md
- ขั้นตอน: สรุปข้อมูลจาก Excel → เสนอ KPI และกราฟให้ผู้ใช้พิจารณา → สร้าง One Page A4 (PDF) → สร้าง Dashboard (HTML) → จัดทำตารางตรวจที่มาของตัวเลข
- กฎ: ตัวเลขทุกค่ามาจากไฟล์ข้อมูลหรือรายงาน คำนวณด้วยโปรแกรม ค่าเฉลี่ยรวมใช้ค่าเฉลี่ยถ่วงน้ำหนัก
  ข้อความผลสำเร็จ อุปสรรค และขั้นต่อไปมาจากรายงานเท่านั้น ระบุแหล่งข้อมูลและวันที่ของข้อมูล
- คงรูปแบบตาม design-rules.md
ก่อนลงมือ ให้เสนอแผนเป็นข้อ ๆ (ไฟล์ที่จะสร้างและขั้นตอน) แล้วรอฉันตอบว่า "ยืนยัน" จึงเริ่มสร้างไฟล์
```
ทางเลือกสำรอง (กรณีเวลาไม่เพียงพอ หรือโมเดลสร้างไม่สำเร็จ)
```
คัดลอกโฟลเดอร์ @skills-solution/project-dashboard ไปไว้ที่ .agents/skills/project-dashboard
```

## ขั้นที่ 3 ใช้งาน Skill
เปิดแชตใหม่
```
/project-dashboard @input/project-report.md @input/training-data.xlsx จัดทำ One Page และ Dashboard ผลการดำเนินโครงการปี 2569 สำหรับผู้บริหาร
```
ตรวจผล: เปิด `output/onepage.pdf` (1 หน้า A4) · เปิด `output/dashboard.html` ด้วยเบราว์เซอร์ แล้วย่อหน้าต่างเพื่อดูการแสดงผลบนจอเล็ก · ตรวจ `output/number-check.md` (ความพึงพอใจรวม 4.52 เป็นค่าเฉลี่ยถ่วงน้ำหนัก)

## ขั้นที่ 4 ทดสอบและปรับปรุง
**ข้อมูลไม่ครบ** — AI ต้องขอไฟล์ข้อมูล ไม่สร้างตัวเลขขึ้นเอง
```
/project-dashboard จัดทำ Dashboard ผลการดำเนินงานไตรมาส 3 ของศูนย์การเรียนรู้เมืองใหม่
```
**เงื่อนไขเพิ่มเติม** — เลือกเนื้อหาให้ตรงผู้ใช้งาน โดยคงรูปแบบและหลักการใช้ตัวเลขเดิม
```
/project-dashboard @input/project-report.md @input/training-data.xlsx จัดทำเฉพาะ Dashboard สำหรับคณะกรรมการจังหวัด เน้นการเข้าถึงรายตำบลและงบประมาณ
```
**ปรับปรุง Skill** เมื่อพบข้อบกพร่อง
```
ปรับ Skill project-dashboard: เพิ่มกฎ [ประเด็นที่พบ] และเพิ่มรายการตรวจใน Checklist คุณภาพ แล้วทดสอบกรณีเดิมอีกครั้ง
```
**ผลลัพธ์ที่คาดหวัง:** One Page A4 และ Dashboard ที่ตัวเลขทุกค่าตรวจสอบย้อนกลับได้ รูปแบบเดียวกับงานปีก่อน
