#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
generate_swimlane.py - Standard Swimlane Diagram Generator
Workflow Discovery Coach Tool
Locks the exact design specification:
- Font: Sarabun
- Horizontal Swimlanes with Role/Department boxes strictly on the left
- Specific color palette per role (Management, Plan, Proposer, AI Assistant, Approver)
- Main flow (Blue), AI flow (Purple), Rework flow (Red dashed)
- Produces responsive HTML with <agent-embed> support and standalone SVG.
"""

import sys
import os
import json
import argparse
import html

# Palette definition according to locked design system
THEME_PALETTE = {
    "admin": {
        "header_bg": "#e2e8f0",
        "header_text": "#334155",
        "lane_bg": "#f8fafc",
        "lane_stroke": "#e2e8f0",
        "node_stroke": "#94a3b8",
        "node_text": "#1e293b",
        "sub_text": "#64748b"
    },
    "plan": {
        "header_bg": "#bae6fd",
        "header_text": "#0369a1",
        "lane_bg": "#f0f9ff",
        "lane_stroke": "#bae6fd",
        "node_stroke": "#0284c7",
        "node_text": "#0369a1",
        "sub_text": "#0284c7"
    },
    "proposer": {
        "header_bg": "#fbcfe8",
        "header_text": "#9d174d",
        "lane_bg": "#fdf2f8",
        "lane_stroke": "#fbcfe8",
        "node_stroke": "#db2777",
        "node_text": "#9d174d",
        "sub_text": "#be185d"
    },
    "ai": {
        "header_bg": "#ddd6fe",
        "header_text": "#6d28d9",
        "lane_bg": "#f5f3ff",
        "lane_stroke": "#ddd6fe",
        "node_stroke": "#7c3aed",
        "node_text": "#6d28d9",
        "sub_text": "#7c3aed"
    },
    "approver": {
        "header_bg": "#fde68a",
        "header_text": "#92400e",
        "lane_bg": "#fffbeb",
        "lane_stroke": "#fde68a",
        "node_stroke": "#d97706",
        "node_text": "#92400e",
        "sub_text": "#b45309"
    }
}

DEFAULT_DEMO_DATA = {
    "title": "แผนภาพกระบวนการเป้าหมาย (To-Be Swimlane)",
    "subtitle": "กระบวนการจัดทำข้อเสนอโครงการ + AI-Assisted ร่าง/ตรวจเกณฑ์ & สรุปแหล่งงบประมาณ",
    "lanes": [
        {"id": "lane_admin", "name": "ฝ่ายบริหาร", "theme": "admin", "height": 115},
        {"id": "lane_plan", "name": "หน่วยแผน", "theme": "plan", "height": 140},
        {"id": "lane_proposer", "name": "ผู้เสนอโครงการ", "theme": "proposer", "height": 140},
        {"id": "lane_ai", "name": "AI Assistant", "subtitle": "(ระบบอัจฉริยะ)", "theme": "ai", "height": 140},
        {"id": "lane_approver", "name": "หัวหน้าหน่วยงาน", "theme": "approver", "height": 130}
    ],
    "nodes": [
        {
            "id": "node_start",
            "lane_id": "lane_admin",
            "type": "start",
            "title": "เริ่มต้น",
            "x": 190, "y": 48, "w": 70, "h": 38
        },
        {
            "id": "node_admin_1",
            "lane_id": "lane_admin",
            "type": "process",
            "title": "มอบแผนยุทธศาสตร์",
            "subtext": "กำหนดกรอบทิศทาง",
            "x": 285, "y": 37, "w": 160, "h": 60
        },
        {
            "id": "node_plan_1",
            "lane_id": "lane_plan",
            "type": "process",
            "title": "ประชุมชี้แจงเกณฑ์",
            "subtext": "& อัปเดตเกณฑ์เข้า AI",
            "x": 275, "y": 172, "w": 180, "h": 66
        },
        {
            "id": "node_proposer_1",
            "lane_id": "lane_proposer",
            "type": "process",
            "title": "ระบุแนวคิดโครงการ",
            "subtext": "ป้อนวัตถุประสงค์ & งบ",
            "x": 275, "y": 322, "w": 180, "h": 66
        },
        {
            "id": "node_ai_1",
            "lane_id": "lane_ai",
            "type": "ai_process",
            "title": "AI ยกร่าง Proposal",
            "subtext": "& Pre-check เกณฑ์แผน<br/>จำแนกเงื่อนไขแหล่งเงิน",
            "x": 275, "y": 470, "w": 180, "h": 74
        },
        {
            "id": "node_proposer_2",
            "lane_id": "lane_proposer",
            "type": "process",
            "title": "ตรวจทาน & ปรับแก้",
            "subtext": "ยืนยันเนื้อหาและงบ",
            "x": 515, "y": 322, "w": 180, "h": 66
        },
        {
            "id": "node_approver_1",
            "lane_id": "lane_approver",
            "type": "decision",
            "title": "ตรวจครบถ้วน?",
            "subtext": "(ดูผล Pre-check)",
            "x": 525, "y": 615, "w": 160, "h": 74
        },
        {
            "id": "node_plan_2",
            "lane_id": "lane_plan",
            "type": "decision",
            "title": "ตรวจความถูกต้อง?",
            "subtext": "โดยหน่วยแผน",
            "x": 735, "y": 168, "w": 160, "h": 74
        },
        {
            "id": "node_ai_2",
            "lane_id": "lane_ai",
            "type": "ai_process",
            "title": "AI สกัดข้อมูลติดตาม",
            "subtext": "แยกหมวดงบ 4 แหล่ง<br/>(แผ่นดิน/รายได้/วิจัย/จังหวัด)",
            "x": 725, "y": 470, "w": 180, "h": 74
        },
        {
            "id": "node_plan_3",
            "lane_id": "lane_plan",
            "type": "final",
            "title": "รับข้อเสนอสมบูรณ์",
            "subtext": "+ Dashboard ติดตามงบ",
            "x": 965, "y": 172, "w": 160, "h": 66
        }
    ],
    "edges": [
        {"from": "node_start", "to": "node_admin_1", "type": "flow"},
        {"from": "node_admin_1", "to": "node_plan_1", "type": "flow", "path": "M 365 97 L 365 172"},
        {"from": "node_plan_1", "to": "node_proposer_1", "type": "flow", "path": "M 365 238 L 365 322"},
        {"from": "node_proposer_1", "to": "node_ai_1", "type": "ai", "path": "M 365 388 L 365 470"},
        {"from": "node_ai_1", "to": "node_proposer_2", "type": "ai", "path": "M 455 507 L 485 507 L 485 355 L 515 355"},
        {"from": "node_proposer_2", "to": "node_approver_1", "type": "flow", "path": "M 605 388 L 605 615"},
        {
            "from": "node_approver_1", "to": "node_proposer_2", "type": "rework",
            "path": "M 525 652 L 480 652 L 480 370 L 515 370",
            "label": "ปรับปรุง", "label_x": 450, "label_y": 649
        },
        {
            "from": "node_approver_1", "to": "node_plan_2", "type": "flow",
            "path": "M 685 652 L 725 652 L 725 205 L 735 205",
            "label": "ครบถ้วน", "label_x": 714, "label_y": 639, "label_type": "success"
        },
        {
            "from": "node_plan_2", "to": "node_proposer_2", "type": "rework",
            "path": "M 815 242 L 815 355 L 695 355",
            "label": "แก้ไข", "label_x": 812, "label_y": 309
        },
        {
            "from": "node_plan_2", "to": "node_ai_2", "type": "ai",
            "path": "M 815 242 L 815 470",
            "label": "ถูกต้อง", "label_x": 846, "label_y": 404, "label_type": "success"
        },
        {"from": "node_ai_2", "to": "node_plan_3", "type": "ai", "path": "M 905 507 L 945 507 L 945 205 L 965 205"}
    ]
}

def generate_svg(data):
    lanes = data.get("lanes", [])
    nodes = data.get("nodes", [])
    edges = data.get("edges", [])
    
    total_width = data.get("width", 1200)
    lane_gap = 10
    start_y = 10
    
    # Calculate lane y positions
    cur_y = start_y
    lane_y_map = {}
    lanes_rendered = []
    
    for l in lanes:
        lh = l.get("height", 130)
        theme = THEME_PALETTE.get(l.get("theme", "admin"), THEME_PALETTE["admin"])
        lane_y_map[l["id"]] = {"y": cur_y, "height": lh, "theme": theme, "info": l}
        
        # Lane SVG components
        subtext_svg = ""
        if l.get("subtitle"):
            subtext_svg = f'<text x="95" y="{cur_y + lh//2 + 20}" font-size="12" font-weight="600" fill="{theme["sub_text"]}" text-anchor="middle">{html.escape(l["subtitle"])}</text>'
            main_text_y = cur_y + lh//2 - 2
        else:
            main_text_y = cur_y + lh//2 + 5
            
        lane_svg = f'''
        <!-- Lane: {html.escape(l["name"])} -->
        <rect x="15" y="{cur_y}" width="{total_width - 30}" height="{lh}" rx="8" fill="{theme["lane_bg"]}" stroke="{theme["lane_stroke"]}" stroke-width="1.2" />
        <rect x="25" y="{cur_y + 10}" width="140" height="{lh - 20}" rx="8" fill="{theme["header_bg"]}" opacity="0.75" />
        <text x="95" y="{main_text_y}" font-size="15" font-weight="700" fill="{theme["header_text"]}" text-anchor="middle">{html.escape(l["name"])}</text>
        {subtext_svg}
        '''
        lanes_rendered.append(lane_svg)
        cur_y += lh + lane_gap
        
    total_height = cur_y + 10

    # Nodes Rendering
    nodes_rendered = []
    for n in nodes:
        ntype = n.get("type", "process")
        nx, ny, nw, nh = n["x"], n["y"], n["w"], n["h"]
        title = n.get("title", "")
        subtext = n.get("subtext", "")
        lane_id = n.get("lane_id")
        theme = lane_y_map.get(lane_id, {}).get("theme", THEME_PALETTE["admin"])

        if ntype == "start":
            node_svg = f'''
            <g transform="translate({nx}, {ny})">
              <rect x="0" y="0" width="{nw}" height="{nh}" rx="{nh//2}" fill="#16a34a" filter="url(#box-shadow)" />
              <text x="{nw//2}" y="{nh//2 + 5}" fill="#fff" font-size="13" font-weight="700" text-anchor="middle">{html.escape(title)}</text>
            </g>'''
        elif ntype == "final":
            sub_lines = subtext.split("<br/>")
            sub_svg = ""
            for idx, sl in enumerate(sub_lines):
                sub_svg += f'<text x="{nw//2}" y="{nh//2 + 14 + idx*15}" font-size="11.5" fill="#bfdbfe" text-anchor="middle">{html.escape(sl)}</text>'
            node_svg = f'''
            <g transform="translate({nx}, {ny})">
              <rect x="0" y="0" width="{nw}" height="{nh}" rx="10" fill="#1d4ed8" filter="url(#box-shadow)" />
              <text x="{nw//2}" y="{nh//2 - 4 if subtext else nh//2 + 5}" font-size="13" font-weight="700" fill="#fff" text-anchor="middle">{html.escape(title)}</text>
              {sub_svg}
            </g>'''
        elif ntype == "decision":
            sub_svg = f'<text x="{nw//2}" y="{nh//2 + 13}" font-size="11.5" fill="#64748b" text-anchor="middle">{html.escape(subtext)}</text>' if subtext else ""
            node_svg = f'''
            <g transform="translate({nx}, {ny})">
              <polygon points="{nw//2},0 {nw},{nh//2} {nw//2},{nh} 0,{nh//2}" fill="#fff" stroke="{theme["node_stroke"]}" stroke-width="2" filter="url(#box-shadow)" />
              <text x="{nw//2}" y="{nh//2 - 4 if subtext else nh//2 + 5}" font-size="13" font-weight="700" fill="{theme["node_text"]}" text-anchor="middle">{html.escape(title)}</text>
              {sub_svg}
            </g>'''
        elif ntype == "ai_process":
            sub_lines = subtext.split("<br/>")
            sub_svg = ""
            for idx, sl in enumerate(sub_lines):
                sub_svg += f'<text x="{nw//2}" y="{nh//2 + 8 + idx*16}" font-size="11" fill="{theme["sub_text"]}" text-anchor="middle">{html.escape(sl)}</text>'
            node_svg = f'''
            <g transform="translate({nx}, {ny})">
              <rect x="0" y="0" width="{nw}" height="{nh}" rx="10" fill="#fff" stroke="#7c3aed" stroke-width="2" filter="url(#box-shadow)" />
              <text x="{nw//2}" y="{nh//2 - 10 if subtext else nh//2 + 5}" font-size="13" font-weight="700" fill="#6d28d9" text-anchor="middle">{html.escape(title)}</text>
              {sub_svg}
            </g>'''
        else: # default process
            sub_lines = subtext.split("<br/>")
            sub_svg = ""
            for idx, sl in enumerate(sub_lines):
                sub_svg += f'<text x="{nw//2}" y="{nh//2 + 12 + idx*16}" font-size="11.5" fill="{theme["sub_text"]}" text-anchor="middle">{html.escape(sl)}</text>'
            node_svg = f'''
            <g transform="translate({nx}, {ny})">
              <rect x="0" y="0" width="{nw}" height="{nh}" rx="10" fill="#fff" stroke="{theme["node_stroke"]}" stroke-width="1.8" filter="url(#box-shadow)" />
              <text x="{nw//2}" y="{nh//2 - 6 if subtext else nh//2 + 5}" font-size="13" font-weight="700" fill="{theme["node_text"]}" text-anchor="middle">{html.escape(title)}</text>
              {sub_svg}
            </g>'''
        nodes_rendered.append(node_svg)

    # Edges Rendering
    edges_rendered = []
    for e in edges:
        etype = e.get("type", "flow")
        d_path = e.get("path", "")
        label = e.get("label", "")
        lx = e.get("label_x", 0)
        ly = e.get("label_y", 0)
        ltype = e.get("label_type", "rework" if etype == "rework" else "flow")

        stroke_color = "#2563eb"
        marker_id = "arrow-blue"
        dash_style = ""
        
        if etype == "ai":
            stroke_color = "#7c3aed"
            marker_id = "arrow-purple"
        elif etype == "rework":
            stroke_color = "#ef4444"
            marker_id = "arrow-red"
            dash_style = 'stroke-dasharray="6,4"'

        edge_svg = f'<path d="{d_path}" fill="none" stroke="{stroke_color}" stroke-width="2" {dash_style} marker-end="url(#{marker_id})" />'
        
        if label and lx and ly:
            if ltype == "success":
                badge_bg = "#dcfce7"
                badge_text = "#15803d"
            else:
                badge_bg = "#fee2e2"
                badge_text = "#b91c1c"
            bw = len(label) * 12 + 16
            label_svg = f'''
            <rect x="{lx - bw//2}" y="{ly - 14}" width="{bw}" height="20" rx="4" fill="{badge_bg}" />
            <text x="{lx}" y="{ly}" font-size="11" font-weight="700" fill="{badge_text}" text-anchor="middle">{html.escape(label)}</text>
            '''
            edge_svg += label_svg

        edges_rendered.append(edge_svg)

    # Final SVG assembly
    svg_content = f'''<svg viewBox="0 0 {total_width} {total_height}" width="{total_width}" height="{total_height}" class="w-full h-auto block" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <marker id="arrow-blue" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
      <path d="M 0 1 L 9 5 L 0 9 z" fill="#2563eb" />
    </marker>
    <marker id="arrow-red" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
      <path d="M 0 1 L 9 5 L 0 9 z" fill="#ef4444" />
    </marker>
    <marker id="arrow-purple" viewBox="0 0 10 10" refX="7" refY="5" markerWidth="6" markerHeight="6" orient="auto-start-reverse">
      <path d="M 0 1 L 9 5 L 0 9 z" fill="#7c3aed" />
    </marker>
    <filter id="box-shadow" x="-5%" y="-5%" width="110%" height="115%" filterUnits="userSpaceOnUse">
      <feDropShadow dx="0" dy="2" stdDeviation="3" flood-color="#0f172a" flood-opacity="0.06" />
    </filter>
  </defs>

  <!-- SWIMLANES -->
  {"".join(lanes_rendered)}

  <!-- CONNECTIONS -->
  {"".join(edges_rendered)}

  <!-- NODES -->
  {"".join(nodes_rendered)}
</svg>'''
    return svg_content, total_width, total_height

def generate_html(data):
    title = data.get("title", "แผนภาพกระบวนการเป้าหมาย (To-Be Swimlane)")
    subtitle = data.get("subtitle", "")
    svg_content, tw, th = generate_svg(data)

    html_page = f'''<!DOCTYPE html>
<html lang="th">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{html.escape(title)}</title>
  <script src="https://www.gstatic.com/antigravity/web/dev/tailwindcss.min.js"></script>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Sarabun:wght@300;400;500;600;700&display=swap');
    * {{ font-family: 'Sarabun', sans-serif; }}
  </style>
</head>
<body class="bg-transparent text-[var(--foreground)] antialiased p-2">
  <div class="bg-[var(--card)] text-[var(--foreground)] border border-[var(--border)] rounded-2xl p-6 shadow-sm max-w-full overflow-x-auto">
    <!-- Header -->
    <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6 pb-4 border-b border-[var(--border)]">
      <div>
        <h2 class="text-xl font-bold text-slate-800 tracking-tight">{html.escape(title)}</h2>
        <p class="text-sm text-slate-500 mt-1">{html.escape(subtitle)}</p>
      </div>
      <div class="flex items-center gap-4 text-xs font-medium text-slate-600 bg-slate-50 px-3 py-2 rounded-lg border border-slate-200">
        <div class="flex items-center gap-1.5">
          <span class="w-3 h-3 rounded-full bg-purple-600 inline-block"></span>
          <span>AI Assistant</span>
        </div>
        <div class="flex items-center gap-1.5">
          <span class="w-5 h-0.5 bg-blue-600 inline-block"></span>
          <span>เส้นทางงาน</span>
        </div>
        <div class="flex items-center gap-1.5">
          <span class="w-5 h-0.5 border-t-2 border-dashed border-red-500 inline-block"></span>
          <span>ส่งกลับแก้ไข</span>
        </div>
      </div>
    </div>

    <!-- SVG Swimlane Container -->
    <div class="w-full overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-inner">
      {svg_content}
    </div>
  </div>
</body>
</html>'''
    return html_page

def main():
    parser = argparse.ArgumentParser(description="Generate Standard Swimlane Diagram")
    parser.add_argument("--input", "-i", help="Path to input JSON workflow definition file")
    parser.add_argument("--output", "-o", default="to-be-swimlane.html", help="Path to output HTML file")
    parser.add_argument("--svg-output", "-s", default="to-be-swimlane.svg", help="Path to output standalone SVG file")
    parser.add_argument("--demo", action="store_true", help="Generate default reference To-Be swimlane")
    args = parser.parse_args()

    if args.input and os.path.exists(args.input):
        with open(args.input, "r", encoding="utf-8") as f:
            data = json.load(f)
    else:
        data = DEFAULT_DEMO_DATA

    html_content = generate_html(data)
    with open(args.output, "w", encoding="utf-8") as f:
        f.write(html_content)

    svg_content, _, _ = generate_svg(data)
    with open(args.svg_output, "w", encoding="utf-8") as f:
        f.write(svg_content)

    print(f"Successfully generated:")
    print(f" - HTML: {os.path.abspath(args.output)}")
    print(f" - SVG:  {os.path.abspath(args.svg_output)}")

if __name__ == "__main__":
    main()
