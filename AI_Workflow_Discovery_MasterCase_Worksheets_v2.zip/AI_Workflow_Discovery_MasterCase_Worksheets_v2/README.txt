AI Workflow Discovery — Master Case และใบงาน รุ่นเพิ่มเติม

Master_Case: PDF สำหรับอ่าน และ Master_Case_Learner.md สำหรับคัดลอกข้อความ
Master_Case/Test_Inputs: ข้อมูลทดสอบ 3 กรณี ใช้แยกบริบททีละกรณี
Worksheets: ใบงาน Word Modules 1–6, Test Log และแบบรายงาน
Skill_Starter: อ่าน README.md แล้วเติม SKILL.md และไฟล์ประกอบ
Final_Project: Checklist และคำชี้แจงงาน มี Word และ Markdown

Word เปิดด้วย Microsoft Word; PDF เปิดด้วย Preview หรือ Acrobat; .md เปิดด้วยโปรแกรมแก้ไขข้อความ เช่น VS Code หรือ TextEdit โหมดข้อความธรรมดา
