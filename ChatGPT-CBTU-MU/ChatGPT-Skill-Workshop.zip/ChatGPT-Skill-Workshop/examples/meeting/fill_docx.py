#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""เติมข้อมูลลงในแม่แบบ Word (.docx) โดยไม่แตะรูปแบบเอกสาร
ใช้:  python3 fill_docx.py แม่แบบ.docx ข้อมูล.json ผลลัพธ์.docx
- {{key}}            แทนด้วยค่าจาก JSON
- {{#list}}...       ย่อหน้าที่มีเครื่องหมายนี้จะถูกทำซ้ำตามจำนวนรายการใน list
                     ภายในใช้ {{.}} (รายการเป็นข้อความ) หรือ {{field}} (รายการเป็น object)
- ขึ้นบรรทัดใหม่ภายในค่า ใช้ \\n
ใช้เฉพาะไลบรารีมาตรฐานของ Python ไม่ต้องติดตั้งเพิ่ม
"""
import json, re, sys, zipfile
from xml.sax.saxutils import escape

def xml_value(v):
    v = escape(str(v))
    return v.replace("\n", '</w:t><w:br/><w:t xml:space="preserve">')

def fill(xml, data, used):
    def expand(m):
        par = m.group(0)
        if "txbxContent" in par:
            return par
        loop = re.search(r"\{\{#(\w+)\}\}", par)
        if not loop:
            return par
        name = loop.group(1); used.add(name)
        items = data.get(name)
        if not isinstance(items, list) or not items:
            raise SystemExit("ข้อผิดพลาด: ต้องมีรายการ '%s' อย่างน้อย 1 รายการ" % name)
        out = []
        for it in items:
            p = par.replace(loop.group(0), "")
            if isinstance(it, dict):
                for k, v in it.items():
                    p = p.replace("{{%s}}" % k, xml_value(v))
            else:
                p = p.replace("{{.}}", xml_value(it))
            out.append(p)
        return "".join(out)
    xml = re.sub(r"<w:p[ >].*?</w:p>", expand, xml, flags=re.S)
    for k, v in data.items():
        if isinstance(v, (list, dict)):
            continue
        token = "{{%s}}" % k
        if token in xml:
            used.add(k); xml = xml.replace(token, xml_value(v))
    xml = re.sub(r"<w:t>(?=[^<]*(?:^ | $|  ))", '<w:t xml:space="preserve">', xml)
    return xml

def main():
    if len(sys.argv) != 4:
        raise SystemExit(__doc__)
    tpl, data_path, out = sys.argv[1:]
    data = json.load(open(data_path, encoding="utf-8"))
    used, left = set(), []
    zin = zipfile.ZipFile(tpl)
    zout = zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED)
    for item in zin.infolist():
        raw = zin.read(item.filename)
        if re.match(r"word/(document|header\d*|footer\d*)\.xml$", item.filename):
            xml = fill(raw.decode("utf-8"), data, used)
            left += re.findall(r"\{\{[^}]*\}\}", xml)
            raw = xml.encode("utf-8")
        zout.writestr(item, raw)
    zout.close()
    if left:
        raise SystemExit("ข้อผิดพลาด: ข้อมูลไม่ครบ ยังเหลือช่อง %s" % sorted(set(left)))
    unused = [k for k in data if k not in used and not k.startswith("_")]
    if unused:
        print("คำเตือน: ข้อมูลที่ไม่ได้ใช้ในแม่แบบ:", ", ".join(unused))
    print("สร้างไฟล์แล้ว:", out)

if __name__ == "__main__":
    main()
